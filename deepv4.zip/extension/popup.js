// popup.js - 插件弹出窗口逻辑
const API_BASE = 'http://127.0.0.1:5000/api';

document.addEventListener('DOMContentLoaded', () => {
    loadSettings();
    loadPageAnalysis();

    $('btnScan').addEventListener('click', scanPage);
    $('btnAnalyze').addEventListener('click', analyzeSelection);
    $('btnDashboard').addEventListener('click', () => {
        chrome.tabs.create({ url: 'http://127.0.0.1:5000' });
    });
    $('threshold').addEventListener('input', (e) => {
        $('thresholdVal').textContent = e.target.value;
        saveSettings();
    });
});

function $(id) { return document.getElementById(id); }

async function loadSettings() {
    const data = await chrome.storage.local.get(['threshold']);
    if (data.threshold) {
        $('threshold').value = data.threshold;
        $('thresholdVal').textContent = data.threshold;
    }
}

async function saveSettings() {
    await chrome.storage.local.set({ threshold: $('threshold').value });
}

async function loadPageAnalysis() {
    const data = await chrome.storage.local.get(['lastAnalysis']);
    if (data.lastAnalysis) {
        updateUI(data.lastAnalysis);
    }
}

async function scanPage() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return;

    try {
        const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: extractPageText,
        });
        if (results && results[0] && results[0].result) {
            const pageText = results[0].result;
            const threshold = parseInt($('threshold').value) / 100;

            // 调用后端API检测
            const resp = await fetch(`${API_BASE}/check-content`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ text: pageText.substring(0, 5000) }),
            });
            const data = await resp.json();

            const analysis = {
                isSpam: data.is_spam,
                score: data.score,
                reasons: data.reasons || [],
                timestamp: new Date().toISOString(),
            };
            await chrome.storage.local.set({ lastAnalysis: analysis });
            updateUI(analysis);

        } else {
            showResult([{ text: '无法读取页面内容', score: 0 }]);
        }
    } catch (e) {
        showResult([{ text: '扫描出错: ' + e.message, score: 0 }]);
    }
}

async function analyzeSelection() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return;

    try {
        const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => window.getSelection()?.toString() || '',
        });
        const text = results[0]?.result || '';
        if (!text) {
            showResult([{ text: '请先在页面上选择文本', score: 0 }]);
            return;
        }

        const resp = await fetch(`${API_BASE}/check-content`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text }),
        });
        const data = await resp.json();

        const analysis = {
            isSpam: data.is_spam,
            score: data.score,
            reasons: data.reasons || [],
            timestamp: new Date().toISOString(),
        };
        updateUI(analysis);

    } catch (e) {
        showResult([{ text: '分析出错: ' + e.message, score: 0 }]);
    }
}

function updateUI(analysis) {
    const score = analysis.score;
    const statusEl = $('pageStatus');
    const countEl = $('suspiciousCount');

    if (score >= 0.7) {
        statusEl.textContent = '高风险';
        statusEl.className = 'value danger';
        countEl.textContent = (analysis.reasons?.length || 0) + ' 项';
        countEl.className = 'value danger';
    } else if (score >= 0.45) {
        statusEl.textContent = '可疑';
        statusEl.className = 'value warn';
        countEl.textContent = (analysis.reasons?.length || 0) + ' 项';
        countEl.className = 'value warn';
    } else {
        statusEl.textContent = '安全';
        statusEl.className = 'value safe';
        countEl.textContent = '0 项';
        countEl.className = 'value safe';
    }

    const reasons = analysis.reasons || [];
    if (reasons.length > 0) {
        showResult(reasons.map(r => ({ text: r, score: analysis.score })));
    } else {
        showResult([{ text: '未检测到可疑内容', score: 0 }]);
    }
}

function showResult(items) {
    const box = $('resultBox');
    box.innerHTML = items.map(item => {
        const cls = item.score >= 0.7 ? 'danger' : item.score >= 0.45 ? 'warn' : 'safe';
        return `<div class="result-item">
            <span class="score" style="color:${cls === 'danger' ? '#ef4444' : cls === 'warn' ? '#f59e0b' : '#10b981'}">
                ${item.score >= 0.45 ? '⚠ ' : '✓ '}
            </span>${item.text}
        </div>`;
    }).join('');
    box.classList.add('show');
}

function extractPageText() {
    // 提取页面中可见的文本内容
    const body = document.body;
    if (!body) return '';

    // 移除 script 和 style 标签
    const clone = body.cloneNode(true);
    const scripts = clone.querySelectorAll('script, style, noscript, iframe, svg');
    scripts.forEach(s => s.remove());

    // 获取文本
    let text = clone.innerText || clone.textContent || '';
    // 清理多余的空白
    text = text.replace(/\s+/g, ' ').trim();
    return text;
}
