// popup.js — ShieldMail v3
const API = 'http://127.0.0.1:5000/api';
let _threshold = 45;

document.addEventListener('DOMContentLoaded', () => {
    loadSettings();
    checkServer();
    loadStats();

    // Tab 切换
    document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', () => switchTab(tab.dataset.tab));
    });

    // 按钮事件
    $('btnScan').addEventListener('click', scanPage);
    $('btnAnalyze').addEventListener('click', analyzeSelection);
    $('btnSummarize').addEventListener('click', summarizePage);
    $('btnTranslate').addEventListener('click', translateSelection);
    $('btnHighlight').addEventListener('click', highlightContent);
    $('btnUrlCheck').addEventListener('click', checkUrl);
    $('btnClearHistory').addEventListener('click', clearHistory);

    // 设置
    $('threshold').addEventListener('input', (e) => { $('thresholdVal').textContent = e.target.value + '%'; _threshold = parseInt(e.target.value); saveSettings(); });
    $('autoScan').addEventListener('change', (e) => { chrome.runtime.sendMessage({ action: 'setAutoScan', value: e.target.checked }); saveSettings(); });

    // URL 输入回车
    $('urlInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') checkUrl(); });
});

function $(id) { return document.getElementById(id); }

function switchTab(name) {
    document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === name));
    document.querySelectorAll('.content').forEach(c => c.classList.toggle('active', c.id === 'tab-' + name));
    if (name === 'history') loadHistory();
}

// ==================== 设置 ====================
async function loadSettings() {
    const data = await chrome.storage.local.get(['threshold', 'autoScan']);
    if (data.threshold) { _threshold = data.threshold; $('threshold').value = data.threshold; $('thresholdVal').textContent = data.threshold + '%'; }
    if (data.autoScan !== undefined) $('autoScan').checked = data.autoScan;
}
async function saveSettings() { await chrome.storage.local.set({ threshold: _threshold }); }

// ==================== 服务检测 ====================
async function checkServer() {
    try {
        const r = await fetch(API + '/llm/status'); const d = await r.json();
        if (d.success && d.enabled) updateStatus('online', '服务运行中 · DeepSeek 已连接');
        else if (d.success) updateStatus('online', '服务运行中 (本地模式)');
        else updateStatus('offline', '请启动服务: python app.py');
    } catch (_) { updateStatus('offline', '无法连接 · 请运行 python app.py'); }
}
function updateStatus(s, t) { $('statusDot').className = 'dot ' + s; $('statusText').textContent = t; }

// ==================== 统计 ====================
async function loadStats() {
    const s = await chrome.storage.local.get(['totalScans', 'totalBlocked']);
    $('scanStats').innerHTML = `
        <div class="stat-mini"><div class="sv">${s.totalScans || 0}</div><div class="sl">已扫描</div></div>
        <div class="stat-mini"><div class="sv" style="color:var(--danger)">${s.totalBlocked || 0}</div><div class="sl">已拦截</div></div>
    `;
}

// ==================== 扫描 ====================
async function scanPage() {
    $('btnScan').disabled = true; $('btnScan').innerHTML = '&#x1f50d; 正在扫描...'; hideResult();
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab) return showError('无法获取页面');
        if (/^(chrome|edge):\/\//.test(tab.url)) return showError('浏览器内建页面受保护，请在普通网页使用');

        let text = '';
        try { const r = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => (document.body?.innerText || '').substring(0, 8000) }); text = r[0]?.result || ''; }
        catch (_) { return showError('此页面受浏览器保护，无法扫描'); }

        if (!text) return showError('页面无文本');
        const r = await fetch(API + '/check-content', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text }) });
        const d = await r.json();
        if (!d.success) return showError('检测失败');
        showResult(d);
        chrome.runtime.sendMessage({ action: 'forceScan' });
        loadStats();
    } catch (e) { showError('扫描失败: ' + e.message); }
    $('btnScan').disabled = false; $('btnScan').innerHTML = '&#x1f50d; 扫描当前页面';
}

async function analyzeSelection() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return;
    $('btnAnalyze').disabled = true; hideResult();
    try {
        let text = '';
        try { const r = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => window.getSelection()?.toString() || '' }); text = r[0]?.result || ''; }
        catch (_) { return showError('浏览器页面受保护'); }
        if (!text) return showError('请先选中文本');
        const r = await fetch(API + '/check-content', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text }) });
        showResult(await r.json());
    } catch (e) { showError('分析失败'); }
    $('btnAnalyze').disabled = false;
}

async function translateSelection() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return;
    $('btnTranslate').disabled = true; hideResult();
    try {
        let text = '';
        try { const r = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => window.getSelection()?.toString() || '' }); text = r[0]?.result || ''; }
        catch (_) { return showError('浏览器页面受保护'); }
        if (!text) return showError('请先选中文本');
        const r = await fetch(API + '/ai/translate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text, direction: 'auto' }) });
        const d = await r.json();
        if (d.success) showResultText('AI 翻译', 'success', [d.translated]);
        else showError(d.message || '翻译失败');
    } catch (_) { showError('翻译失败'); }
    $('btnTranslate').disabled = false;
}

async function highlightContent() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return;
    try {
        let text = '';
        try { const r = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => (document.body?.innerText || '').substring(0, 5000) }); text = r[0]?.result || ''; }
        catch (_) { return showError('浏览器页面受保护'); }
        const r = await fetch(API + '/check-content', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text }) });
        const d = await r.json();
        const keywords = (d.reasons || []).filter(r => r.includes('关键词')).join(' ').match(/[\u4e00-\u9fff]{2,}|\w{3,}/g) || [];
        if (!keywords.length) return showError('未检测到可疑关键词');
        await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: hk, args: [keywords] });
        showResultText('高亮完成', 'warn', [`已标记 ${keywords.length} 个可疑词`]);
    } catch (_) { showError('高亮失败'); }
}
function hk(kw) { const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false); const n = []; while (w.nextNode()) n.push(w.currentNode); n.forEach(nd => { let h = nd.textContent; let c = false; kw.forEach(k => { const re = new RegExp(`(${k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi'); if (re.test(h)) { h = h.replace(re, '<span style="background:#fef2f2;color:#ef4444;font-weight:700;padding:0 3px;border-radius:2px;border:1px solid rgba(239,68,68,.3)">$1</span>'); c = true; } }); if (c) { const sp = document.createElement('span'); sp.innerHTML = h; nd.parentNode.replaceChild(sp, nd); } }); }

async function checkUrl() {
    const url = $('urlInput').value.trim();
    if (!url) return showError('请输入 URL');
    $('btnUrlCheck').disabled = true; hideResult();
    try {
        const r = await fetch(API + '/check-content', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text: 'URL检测: ' + url }) });
        const d = await r.json();
        showResult(d);
    } catch (_) { showError('检测失败'); }
    $('btnUrlCheck').disabled = false;
}

async function summarizePage() {
    $('btnSummarize').disabled = true; $('btnSummarize').innerHTML = '&#x1f9e0; AI 正在总结...';
    $('summaryCard').style.display = 'none';
    try {
        const resp = await chrome.runtime.sendMessage({ action: 'summarizePage' });
        if (resp.success) {
            $('summaryText').textContent = resp.summary;
            $('summaryCard').style.display = 'block';
        } else {
            showError(resp.message || '总结失败');
        }
    } catch (_) { showError('总结服务不可用'); }
    $('btnSummarize').disabled = false; $('btnSummarize').innerHTML = '&#x1f9e0; AI 总结页面内容';
}

// ==================== 历史 ====================
async function loadHistory() {
    const d = await chrome.storage.local.get(['history']);
    const h = d.history || [];
    if (!h.length) { $('historyList').innerHTML = '<div class="empty-state">暂无扫描记录</div>'; return; }
    $('historyList').innerHTML = h.map(item => `
        <div class="history-item">
            <div class="hi-domain">${item.domain}</div>
            <div class="hi-url">${item.url}</div>
            <div class="hi-meta">
                <span class="hi-badge ${item.isSpam ? 'danger' : item.score >= 35 ? 'warn' : 'safe'}">${item.isSpam ? '高危' : item.score >= 35 ? '可疑' : '安全'} ${item.score}%</span>
                <span style="color:var(--text3)">${new Date(item.time).toLocaleTimeString()}</span>
            </div>
        </div>
    `).join('');
}

async function clearHistory() {
    await chrome.storage.local.set({ history: [], totalScans: 0, totalBlocked: 0 });
    loadHistory();
    loadStats();
}

// ==================== UI ====================
function showResult(d) { const s = d.score || 0; const sp = d.is_spam; const b = $('resultBadge'); b.textContent = sp ? '高风险' : s >= 0.35 ? '可疑' : '安全'; b.className = 'r-badge ' + (sp ? 'danger' : s >= 0.35 ? 'warn' : 'safe'); $('resultScore').textContent = '评分: ' + (s * 100).toFixed(0) + '%'; const rs = d.reasons || []; $('resultItems').innerHTML = rs.length ? rs.map(r => `<div class="r-item">${r}</div>`).join('') : '<div class="r-item" style="color:var(--success)">✅ 未检测到可疑内容</div>';
    // LLM 深度分析
    let deepHtml = '';
    if (d.llm && d.llm.category) deepHtml += `<div class="r-item"><span class="r-label">AI 分类:</span> ${d.llm.category} ${d.llm.risk_level ? '('+d.llm.risk_level+')' : ''}</div>`;
    if (d.llm && d.llm.reasoning) deepHtml += `<div class="r-item"><span class="r-label">分析:</span> ${d.llm.reasoning}</div>`;
    if (d.fraud && d.fraud.is_fraud) deepHtml += `<div class="r-item" style="color:var(--danger)"><span class="r-label">诈骗检测:</span> ${d.fraud.fraud_type} (${Math.round(d.fraud.risk_score*100)}%)</div>`;
    if (d.urls && (d.urls.warnings||[]).length) deepHtml += `<div class="r-item" style="color:var(--warning)"><span class="r-label">链接风险:</span> ${d.urls.warnings.join('; ')}</div>`;
    if (d.overallRisk && d.overallRisk !== '安全') deepHtml += `<div class="r-item"><span class="r-label">综合风险:</span> ${d.overallRisk}</div>`;
    $('deepItems').innerHTML = deepHtml;
    $('resultCard').classList.add('show');
    // 隐藏总结卡片
    $('summaryCard').style.display = 'none';
}
function showResultText(title, type, lines) { $('resultBadge').textContent = title; $('resultBadge').className = 'r-badge ' + type; $('resultScore').textContent = ''; $('resultItems').innerHTML = lines.map(l => `<div class="r-item">${l}</div>`).join(''); $('resultCard').classList.add('show'); }
function showError(msg) { $('resultBadge').textContent = '错误'; $('resultBadge').className = 'r-badge danger'; $('resultScore').textContent = ''; $('resultItems').innerHTML = `<div class="r-item" style="color:var(--danger)">${msg}</div>`; $('resultCard').classList.add('show'); }
function hideResult() { $('resultCard').classList.remove('show'); }
