// content.js - 内容脚本，注入到所有页面
(function () {
    'use strict';

    // 监听来自popup的消息
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'getPageText') {
            const text = document.body?.innerText || '';
            sendResponse({ text: text.substring(0, 10000) });
        } else if (request.action === 'getSelectedText') {
            const text = window.getSelection()?.toString() || '';
            sendResponse({ text: text });
        } else if (request.action === 'highlightSpam') {
            highlightSuspiciousContent(request.keywords || []);
            sendResponse({ success: true });
        }
        return true;
    });

    // 高亮可疑内容
    function highlightSuspiciousContent(keywords) {
        if (keywords.length === 0) return;

        const walker = document.createTreeWalker(
            document.body,
            NodeFilter.SHOW_TEXT,
            null,
            false
        );

        const textNodes = [];
        while (walker.nextNode()) {
            textNodes.push(walker.currentNode);
        }

        textNodes.forEach(node => {
            let html = node.textContent;
            let modified = false;

            keywords.forEach(kw => {
                const regex = new RegExp(`(${kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
                if (regex.test(html)) {
                    html = html.replace(regex,
                        '<span style="background:#fef2f2;color:#ef4444;font-weight:bold;padding:0 2px;border-radius:2px;">$1</span>'
                    );
                    modified = true;
                }
            });

            if (modified) {
                const span = document.createElement('span');
                span.innerHTML = html;
                node.parentNode.replaceChild(span, node);
            }
        });
    }
})();
