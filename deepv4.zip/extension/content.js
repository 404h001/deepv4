// content.js — ShieldMail 内容脚本
(function () {
    'use strict';

    const API = 'http://127.0.0.1:5000/api';

    // ==================== 消息监听 ====================
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'getPageText') {
            sendResponse({ text: (document.body?.innerText || '').substring(0, 10000) });
        } else if (request.action === 'getSelectedText') {
            sendResponse({ text: window.getSelection()?.toString() || '' });
        } else if (request.action === 'highlightKeywords') {
            highlightKeywords(request.keywords || []);
            sendResponse({ success: true });
        } else if (request.action === 'showBanner') {
            showBanner(request.level, request.message);
            sendResponse({ success: true });
        } else if (request.action === 'showToast') {
            showToast(request.data, request.duration || 2500);
            sendResponse({ success: true });
        } else if (request.action === 'autoCheck') {
            autoCheckPage();
            sendResponse({ success: true });
        }
        return true;
    });

    // ==================== 自动页面检测 ====================
    let _checked = false;
    async function autoCheckPage() {
        if (_checked) return;
        _checked = true;
        try {
            const url = location.href;
            // 只在有内容的页面检测
            const bodyText = (document.body?.innerText || '').substring(0, 6000);
            if (bodyText.length < 200) return;

            const resp = await fetch(API + '/check-content', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ text: bodyText }),
            });
            const data = await resp.json();
            if (!data.success) return;

            const score = data.score || 0;
            if (score >= 0.45) {
                const level = score >= 0.7 ? 'danger' : 'warn';
                const msg = `ShieldMail 检测到此页面包含可疑内容 (${(score*100).toFixed(0)}%)`;
                showBanner(level, msg);
                showFloatingBadge(score);
            }

            // 邮件平台特殊检测
            if (isEmailPlatform()) {
                checkEmailContent();
            }
        } catch (_) { }
    }

    function isEmailPlatform() {
        const host = location.hostname;
        return /mail\.(google|qq|163|126|sina|sohu|aliyun|outlook|office|live)\.com/.test(host);
    }

    async function checkEmailContent() {
        // 尝试检测邮件正文区域
        const selectors = [
            '[role="main"]', '.message-body', '.email-content', '.mail-content',
            '[data-testid="message-view-body"]', '.reading-content', '#content',
            '.msg-content', '.read-content', '[class*="message"]', '[class*="email"]',
        ];
        for (const sel of selectors) {
            const el = document.querySelector(sel);
            if (el && el.innerText.length > 50) {
                const text = el.innerText.substring(0, 3000);
                try {
                    const resp = await fetch(API + '/check-content', {
                        method: 'POST', headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ text }),
                    });
                    const data = await resp.json();
                    if (data.is_spam) {
                        showBanner('danger', `ShieldMail: 此邮件疑似垃圾/钓鱼邮件 (${(data.score*100).toFixed(0)}%) — 已自动检测`);
                    }
                } catch (_) { }
                break;
            }
        }
    }

    // ==================== UI 组件 ====================
    function showBanner(level, message) {
        removeExisting('shieldmail-banner');
        const banner = document.createElement('div');
        banner.className = 'shieldmail-banner ' + level;
        banner.innerHTML = `<span>&#x1f6e1;&#xfe0f; ${message}</span><span class="sm-close" onclick="this.parentElement.remove()">&#x2715;</span>`;
        document.body.prepend(banner);
        setTimeout(() => banner.remove(), 8000);
    }

    function showFloatingBadge(score) {
        removeExisting('shieldmail-badge');
        const badge = document.createElement('div');
        badge.className = 'shieldmail-badge';
        badge.innerHTML = `&#x1f6e1;&#xfe0f; 可疑 ${(score*100).toFixed(0)}% <span class="sm-close" onclick="this.parentElement.remove()">&#x2715;</span>`;
        badge.onclick = () => {
            chrome.runtime.sendMessage({ action: 'openPopup' });
        };
        document.body.appendChild(badge);
    }

    function showToast(data, duration) {
        const score = data.score || 0;
        const level = data.isSpam ? 'danger' : score >= 35 ? 'warn' : 'safe';
        const emoji = data.isSpam ? '&#x1f6a8;' : score >= 35 ? '&#x26a0;&#xfe0f;' : '&#x2705;';
        const label = data.isSpam ? '高风险' : score >= 35 ? '可疑' : '安全';
        const reasonsStr = (data.reasons || []).slice(0, 2).join(', ');
        const bgColor = level === 'danger' ? 'rgba(255,71,87,.92)' : level === 'warn' ? 'rgba(255,165,2,.92)' : 'rgba(46,213,115,.92)';
        const textColor = level === 'warn' ? '#111' : '#fff';

        removeExisting('shieldmail-toast');
        const toast = document.createElement('div');
        toast.className = 'shieldmail-toast';
        toast.style.cssText = `position:fixed;top:0;left:0;right:0;z-index:2147483647;padding:10px 20px;font-size:.82rem;font-weight:600;text-align:center;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:${bgColor};color:${textColor};animation:smSlideDown .35s ease;display:flex;align-items:center;justify-content:center;gap:10px`;
        toast.innerHTML = `${emoji} ShieldMail: ${label} ${score}% ${reasonsStr ? '· '+reasonsStr : ''}`;
        document.body.prepend(toast);
        setTimeout(() => {
            toast.style.animation = 'smSlideUp .3s ease forwards';
            setTimeout(() => toast.remove(), 350);
        }, duration);
        // 注入降级动画
        if (!document.getElementById('sm-toast-style')) {
            const s = document.createElement('style');
            s.id = 'sm-toast-style';
            s.textContent = '@keyframes smSlideDown{from{transform:translateY(-100%);opacity:0}to{transform:translateY(0);opacity:1}}@keyframes smSlideUp{from{transform:translateY(0);opacity:1}to{transform:translateY(-100%);opacity:0}}';
            document.head.appendChild(s);
        }
    }

    function highlightKeywords(keywords) {
        const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
        const nodes = [];
        while (walker.nextNode()) nodes.push(walker.currentNode);
        nodes.forEach(node => {
            if (node.parentElement?.classList.contains('shieldmail-highlight')) return;
            let html = node.textContent;
            let changed = false;
            keywords.forEach(kw => {
                const re = new RegExp(`(${kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
                if (re.test(html)) {
                    html = html.replace(re, '<span class="shieldmail-highlight">$1</span>');
                    changed = true;
                }
            });
            if (changed) {
                const span = document.createElement('span');
                span.innerHTML = html;
                node.parentNode.replaceChild(span, node);
            }
        });
    }

    function removeExisting(className) {
        document.querySelectorAll('.' + className).forEach(el => el.remove());
    }

    // ==================== 右键菜单 ====================
    document.addEventListener('contextmenu', (e) => {
        const selection = window.getSelection()?.toString().trim();
        if (selection && selection.length > 5) {
            // 存储选中文本供 background 使用
            window.__shieldmail_selection = selection;
        }
    });

    // ==================== 自动触发 ====================
    if (document.readyState === 'complete') {
        setTimeout(autoCheckPage, 1500);
    } else {
        window.addEventListener('load', () => setTimeout(autoCheckPage, 1500));
    }
})();
