// background.js - 后台服务 worker
chrome.runtime.onInstalled.addListener(() => {
    console.log('智能反垃圾邮件过滤器已安装');
    chrome.storage.local.set({
        threshold: 45,
        enabled: true,
    });
});

// 监听标签页更新
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url && tab.url.startsWith('http')) {
        const settings = await chrome.storage.local.get(['enabled']);
        if (!settings.enabled) return;

        // 可选：自动扫描页面（仅在用户开启时）
        const autoScan = await chrome.storage.local.get(['autoScan']);
        if (autoScan.autoScan) {
            try {
                chrome.tabs.sendMessage(tabId, { action: 'getPageText' }, (response) => {
                    if (chrome.runtime.lastError) return;
                    // 页面文本已获取，由 popup 触发分析
                });
            } catch (e) {
                // 忽略不可注入的页面
            }
        }
    }
});

// 通知
function showNotification(title, message) {
    chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icons/icon48.png',
        title: title,
        message: message,
        priority: 2,
    });
}

// 监听来自 popup 的报警请求
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'alert') {
        showNotification('垃圾邮件预警', request.message);
        sendResponse({ success: true });
    }
    return true;
});
