// background.js — ShieldMail Service Worker v3
const API = 'http://127.0.0.1:5000/api';
const SCAN_DEBOUNCE = {};

chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'install') {
        chrome.storage.local.set({ threshold: 45, autoScan: true, history: [], totalScans: 0, totalBlocked: 0 });
    }
});

chrome.contextMenus?.removeAll(() => {
    chrome.contextMenus?.create({ id: 'sm-scan', title: 'ShieldMail: 分析选中文本', contexts: ['selection'] });
    chrome.contextMenus?.create({ id: 'sm-translate', title: 'ShieldMail: AI 翻译选中文本', contexts: ['selection'] });
    chrome.contextMenus?.create({ id: 'sm-scan-page', title: 'ShieldMail: 检测当前页面', contexts: ['page'] });
});

chrome.contextMenus?.onClicked.addListener(async (info, tab) => {
    if (!tab?.id) return;
    if (info.menuItemId === 'sm-scan' && info.selectionText) notifyResult(await analyzeText(tab.id, info.selectionText), tab.id);
    else if (info.menuItemId === 'sm-translate' && info.selectionText) await translateAndNotify(info.selectionText);
    else if (info.menuItemId === 'sm-scan-page') await scanAndBadge(tab.id, tab.url, '');
});

// ==================== 页面加载自动扫描 ====================
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
    if (changeInfo.status !== 'complete' || !tab.url?.startsWith('http')) return;
    const settings = await chrome.storage.local.get(['autoScan', 'threshold']);
    if (!settings.autoScan) { resetBadge(tabId); return; }

    const now = Date.now();
    if (SCAN_DEBOUNCE[tabId] && now - SCAN_DEBOUNCE[tabId] < 3000) return;
    SCAN_DEBOUNCE[tabId] = now;

    setTimeout(async () => {
        try {
            const results = await chrome.scripting.executeScript({
                target: { tabId }, func: () => (document.body?.innerText || '').substring(0, 6000),
            });
            const text = results[0]?.result || '';
            if (text.length < 100) { resetBadge(tabId); return; }
            const data = await scanAndBadge(tabId, tab.url, text);
            // 发送结果给 content script 显示 2s 浮层
            if (data) {
                chrome.tabs.sendMessage(tabId, { action: 'showToast', data, duration: 2500 }).catch(() => {});
            }
        } catch (_) { resetBadge(tabId); }
    }, 2000);
});

// ==================== 核心扫描 ====================
async function scanAndBadge(tabId, url, text) {
    try {
        if (!text && url) {
            try { const r = await chrome.scripting.executeScript({ target: { tabId }, func: () => (document.body?.innerText || '').substring(0, 6000) }); text = r[0]?.result || ''; } catch (_) { return null; }
        }
        if (text.length < 50) return null;

        // 1. 基础检测
        const [basicResp, deepResp] = await Promise.all([
            fetch(API + '/check-content', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text: text.substring(0, 5000) }) }).then(r => r.json()),
            fetch(API + '/detect/comprehensive', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ content: text.substring(0, 4000), subject: url?.split('/').pop() || '' }) }).then(r => r.json()).catch(() => null),
        ]);

        const score = basicResp.score || 0;
        const scorePct = Math.round(score * 100);
        const isSpam = basicResp.is_spam;
        const reasons = basicResp.reasons || [];
        const llm = basicResp.llm_analysis;

        // 构建丰富的扫描结果
        const scanData = {
            score: scorePct, isSpam,
            reasons, llm,
            fraud: deepResp?.fraud || null,
            urls: deepResp?.urls || null,
            identity: deepResp?.identity || null,
            overallRisk: deepResp?.overall_risk || (isSpam ? '高风险' : score >= 35 ? '中风险' : '安全'),
        };

        updateBadge(tabId, scorePct, isSpam);
        await saveToHistory(url, scorePct, isSpam, reasons.slice(0, 3));
        await updateStats(isSpam);

        if (isSpam) {
            chrome.tabs.sendMessage(tabId, { action: 'showBanner', level: 'danger', message: `ShieldMail: 检测到垃圾/钓鱼内容 (${scorePct}%)` }).catch(() => {});
        }

        return scanData;
    } catch (_) { resetBadge(tabId); return null; }
}

async function updateStats(isSpam) {
    const s = await chrome.storage.local.get(['totalScans', 'totalBlocked']);
    await chrome.storage.local.set({ totalScans: (s.totalScans || 0) + 1, totalBlocked: (s.totalBlocked || 0) + (isSpam ? 1 : 0) });
}

function updateBadge(tabId, score, isSpam) {
    const text = score >= 10 ? score + '%' : score + '';
    const color = isSpam ? '#ff4757' : score >= 35 ? '#ffa502' : '#2ed573';
    chrome.action.setBadgeText({ tabId, text });
    chrome.action.setBadgeBackgroundColor({ tabId, color });
    chrome.action.setTitle({ tabId, title: `ShieldMail: ${isSpam ? '高风险' : score >= 35 ? '可疑' : '安全'} (${score}%)` });
}
function resetBadge(tabId) { chrome.action.setBadgeText({ tabId, text: '' }); }

// ==================== 分析工具 ====================
async function analyzeText(tabId, text) {
    try {
        const r = await fetch(API + '/check-content', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text: text.substring(0, 5000) }) });
        return await r.json();
    } catch (_) { return null; }
}
async function translateAndNotify(text) {
    try {
        const r = await fetch(API + '/ai/translate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text, direction: 'auto' }) });
        const d = await r.json();
        if (d.success) chrome.notifications.create({ type: 'basic', iconUrl: 'icons/icon48.png', title: 'ShieldMail AI 翻译', message: d.translated.substring(0, 250), priority: 1 });
    } catch (_) { }
}
function notifyResult(result, tabId) {
    if (!result?.success) return;
    const s = Math.round(result.score * 100);
    chrome.notifications.create({ type: 'basic', iconUrl: 'icons/icon48.png', title: `ShieldMail: ${result.is_spam ? '高风险' : s >= 35 ? '可疑' : '安全'} (${s}%)`, message: (result.reasons || ['未检测到异常']).slice(0, 3).join('; '), priority: 2 });
}

// ==================== 历史 ====================
async function saveToHistory(url, score, isSpam, reasons) {
    try { new URL(url); } catch (_) { return; }
    const d = await chrome.storage.local.get(['history']);
    const h = d.history || [];
    h.unshift({ url: url.substring(0, 120), domain: new URL(url).hostname, score, isSpam, reasons, time: Date.now() });
    await chrome.storage.local.set({ history: h.slice(0, 50) });
}

// ==================== 消息路由 ====================
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    (async () => {
        if (request.action === 'forceScan') {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (tab?.id) {
                const text = (await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => (document.body?.innerText || '').substring(0, 8000) }))[0]?.result || '';
                const data = await scanAndBadge(tab.id, tab.url, text);
                sendResponse({ success: true, data });
            } else sendResponse({ success: false });
        } else if (request.action === 'getStats') {
            sendResponse(await chrome.storage.local.get(['totalScans', 'totalBlocked', 'history', 'threshold']));
        } else if (request.action === 'clearHistory') {
            await chrome.storage.local.set({ history: [], totalScans: 0, totalBlocked: 0 });
            sendResponse({ success: true });
        } else if (request.action === 'setAutoScan') {
            await chrome.storage.local.set({ autoScan: request.value });
            sendResponse({ success: true });
        } else if (request.action === 'summarizePage') {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (tab?.id) {
                const text = (await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => (document.body?.innerText || '').substring(0, 4000) }))[0]?.result || '';
                const r = await fetch(API + '/ai/summarize-text', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text }) });
                sendResponse(await r.json());
            } else sendResponse({ success: false, message: '无法获取页面' });
        } else if (request.action === 'detectUrl') {
            sendResponse(await detectUrlSafety(request.url));
        }
    })();
    return true;
});

async function detectUrlSafety(url) {
    try {
        const r = await fetch(API + '/check-content', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text: `URL: ${url}` }) });
        const d = await r.json();
        return { success: true, isSpam: d.is_spam, score: d.score, reasons: d.reasons };
    } catch (_) { return { success: false, error: '服务不可用' }; }
}
