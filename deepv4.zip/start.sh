#!/bin/bash
echo "============================================"
echo "  智能反垃圾邮件识别系统"
echo "  Intelligent Anti-Spam Email System"
echo "============================================"
echo ""

cd "$(dirname "$0")"

echo "[1/3] 检查Python环境..."
python3 --version > /dev/null 2>&1
if [ $? -ne 0 ]; then
    echo "[错误] 未找到Python3，请先安装Python 3.9+"
    exit 1
fi
echo "Python环境正常"

echo ""
echo "[2/3] 安装依赖..."
pip3 install -r requirements.txt -q
echo "依赖安装完成"

echo ""
echo "[3/3] 启动系统..."
echo ""
echo "访问地址: http://127.0.0.1:5000"
echo "按 Ctrl+C 停止服务"
echo "============================================"
echo ""

python3 app.py
