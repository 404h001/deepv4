import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE_PATH = os.path.join(BASE_DIR, 'data', 'antispam.db')
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'data', 'uploads')
MODEL_DIR = os.path.join(BASE_DIR, 'data', 'models')
FACE_DIR = os.path.join(BASE_DIR, 'data', 'faces')

SPAM_MODEL_PATH = os.path.join(MODEL_DIR, 'spam_model.pkl')
VECTORIZER_PATH = os.path.join(MODEL_DIR, 'vectorizer.pkl')

SECRET_KEY = 'antispam-secret-key-2024'

# ==================== DeepSeek API 配置 ====================
# API Key (优先读环境变量，否则使用默认值)
# 获取地址: https://platform.deepseek.com/api_keys
DEEPSEEK_API_KEY = os.environ.get('DEEPSEEK_API_KEY', 'sk-3182d6b91d854b7bbf27cb8ff3114ecc')
DEEPSEEK_API_URL = 'https://api.deepseek.com/chat/completions'
DEEPSEEK_MODEL = 'deepseek-chat'
# 是否启用 LLM 分析（需要有效的 API Key）
ENABLE_LLM = bool(DEEPSEEK_API_KEY)

for d in [os.path.dirname(DATABASE_PATH), UPLOAD_FOLDER, MODEL_DIR, FACE_DIR]:
    os.makedirs(d, exist_ok=True)
