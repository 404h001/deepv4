import os
import json
from datetime import datetime
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

from config import SECRET_KEY, UPLOAD_FOLDER, FACE_DIR
from database import (
    init_db, create_user, verify_user, get_user_by_id,
    save_email, get_inbox, get_sent_emails, get_spam_emails,
    mark_as_spam, restore_from_spam, delete_email, get_email_by_id,
    create_warning, get_warnings, mark_warning_read, get_spam_stats,
    get_all_users,
)
from spam_model import spam_detector
from face_model import register_face, verify_face, has_face_registered, FACE_REC_AVAILABLE

app = Flask(__name__, static_folder='frontend', static_url_path='')
app.secret_key = SECRET_KEY
CORS(app)


@app.route('/')
def index():
    return send_from_directory('frontend', 'index.html')


# ==================== 用户认证 ====================

@app.route('/api/register', methods=['POST'])
def api_register():
    data = request.get_json()
    username = data.get('username', '').strip()
    password = data.get('password', '').strip()

    if not username or not password:
        return jsonify({'success': False, 'message': '用户名和密码不能为空'}), 400
    if len(username) < 3:
        return jsonify({'success': False, 'message': '用户名至少3个字符'}), 400
    if len(password) < 6:
        return jsonify({'success': False, 'message': '密码至少6个字符'}), 400

    user_id = create_user(username, password)
    if user_id is None:
        return jsonify({'success': False, 'message': '用户名已存在'}), 400

    return jsonify({'success': True, 'message': '注册成功', 'user_id': user_id})


@app.route('/api/login', methods=['POST'])
def api_login():
    data = request.get_json()
    username = data.get('username', '').strip()
    password = data.get('password', '').strip()

    user = verify_user(username, password)
    if user is None:
        return jsonify({'success': False, 'message': '用户名或密码错误'}), 401

    return jsonify({
        'success': True,
        'message': '登录成功',
        'user': {'id': user['id'], 'username': user['username']}
    })


@app.route('/api/login/face', methods=['POST'])
def api_face_login():
    data = request.get_json()
    username = data.get('username', '').strip()
    face_image = data.get('face_image', '')

    if not username or not face_image:
        return jsonify({'success': False, 'message': '缺少用户名或人脸图像'}), 400

    if not FACE_REC_AVAILABLE:
        return jsonify({'success': False, 'message': '人脸识别服务暂不可用'}), 503

    success, message, user_id = verify_face(face_image, username)
    if not success:
        return jsonify({'success': False, 'message': message}), 401

    return jsonify({
        'success': True,
        'message': '人脸验证成功',
        'user': {'id': user_id, 'username': username}
    })


@app.route('/api/face/register', methods=['POST'])
def api_register_face():
    data = request.get_json()
    user_id = data.get('user_id')
    face_image = data.get('face_image', '')

    if not user_id or not face_image:
        return jsonify({'success': False, 'message': '缺少参数'}), 400
    if not FACE_REC_AVAILABLE:
        return jsonify({'success': False, 'message': '人脸识别服务暂不可用'}), 503

    success, message = register_face(user_id, face_image)
    return jsonify({'success': success, 'message': message})


@app.route('/api/face/status/<username>', methods=['GET'])
def api_face_status(username):
    registered = has_face_registered(username)
    return jsonify({'has_face': registered, 'available': FACE_REC_AVAILABLE})


# ==================== 邮件操作 ====================

@app.route('/api/emails/send', methods=['POST'])
def api_send_email():
    data = request.get_json()
    sender_id = data.get('sender_id')
    receiver_id = data.get('receiver_id')
    subject = data.get('subject', '').strip()
    content = data.get('content', '').strip()

    if not all([sender_id, receiver_id, subject, content]):
        return jsonify({'success': False, 'message': '请填写完整邮件信息'}), 400

    # 先检测发送内容是否为垃圾内容
    full_text = f'{subject} {content}'
    is_spam, spam_score, reasons, llm_result = spam_detector.predict(full_text, subject)

    # AI智能识别：如果检测为垃圾邮件，仍允许发送，但自动归入收件人垃圾箱
    email_id = save_email(sender_id, receiver_id, subject, content,
                          is_spam=1 if is_spam else 0, spam_score=spam_score)

    response_data = {
        'success': True,
        'message': '邮件发送成功',
        'email_id': email_id,
        'spam_check': {'is_spam': is_spam, 'score': spam_score, 'reasons': reasons},
        'llm_analysis': llm_result,
    }

    if is_spam:
        mark_as_spam(email_id)
        sender_info = get_user_by_id(sender_id)
        sender_name = sender_info['username'] if sender_info else '未知'
        warning_msg = f'AI智能识别：来自 {sender_name} 的邮件被检测为垃圾邮件（评分: {spam_score:.0%}），已自动归入垃圾箱'
        create_warning(receiver_id, 'spam_detected', warning_msg)
        response_data['warning'] = warning_msg

    return jsonify(response_data)


@app.route('/api/emails/receive', methods=['POST'])
def api_receive_email():
    """模拟接收外部邮件"""
    data = request.get_json()
    sender_id = data.get('sender_id')
    receiver_id = data.get('receiver_id')
    subject = data.get('subject', '').strip()
    content = data.get('content', '').strip()

    if not all([sender_id, receiver_id, subject]):
        return jsonify({'success': False, 'message': '缺少邮件信息'}), 400

    # 垃圾邮件检测
    full_text = f'{subject} {content}'
    is_spam, spam_score, reasons, llm_result = spam_detector.predict(full_text, subject)

    email_id = save_email(sender_id, receiver_id, subject, content, is_spam=1 if is_spam else 0, spam_score=spam_score)

    response_data = {
        'success': True,
        'message': '邮件接收成功',
        'email_id': email_id,
    }

    if is_spam:
        mark_as_spam(email_id)
        # 创建预警
        try:
            sender = get_user_by_id(sender_id)
            sender_name = sender['username'] if sender else '未知'
        except Exception:
            sender_name = '未知'
        warning_msg = f'检测到来自 {sender_name} 的垃圾邮件，主题: "{subject[:30]}"，已自动拦截到垃圾箱'
        create_warning(receiver_id, 'spam_detected', warning_msg)
        response_data.update({
            'spam_filtered': True,
            'spam_score': spam_score,
            'reasons': reasons,
            'warning': warning_msg,
            'llm_analysis': llm_result,
        })

    response_data['llm_analysis'] = llm_result
    return jsonify(response_data)


@app.route('/api/emails/inbox/<int:user_id>', methods=['GET'])
def api_inbox(user_id):
    emails = get_inbox(user_id)
    return jsonify({'success': True, 'emails': emails})


@app.route('/api/emails/sent/<int:user_id>', methods=['GET'])
def api_sent(user_id):
    emails = get_sent_emails(user_id)
    return jsonify({'success': True, 'emails': emails})


@app.route('/api/emails/spam/<int:user_id>', methods=['GET'])
def api_spam(user_id):
    emails = get_spam_emails(user_id)
    return jsonify({'success': True, 'emails': emails})


@app.route('/api/emails/<int:email_id>', methods=['GET'])
def api_email_detail(email_id):
    email = get_email_by_id(email_id)
    if not email:
        return jsonify({'success': False, 'message': '邮件不存在'}), 404
    return jsonify({'success': True, 'email': email})


@app.route('/api/emails/<int:email_id>/mark-spam', methods=['POST'])
def api_mark_spam(email_id):
    mark_as_spam(email_id)
    return jsonify({'success': True, 'message': '已标记为垃圾邮件'})


@app.route('/api/emails/<int:email_id>/restore', methods=['POST'])
def api_restore(email_id):
    restore_from_spam(email_id)
    return jsonify({'success': True, 'message': '已恢复为正常邮件'})


@app.route('/api/emails/<int:email_id>/delete', methods=['POST'])
def api_delete(email_id):
    delete_email(email_id)
    return jsonify({'success': True, 'message': '邮件已删除'})


# ==================== 内容检测 ====================

@app.route('/api/check-content', methods=['POST'])
def api_check_content():
    """实时检测文本内容是否为垃圾内容"""
    data = request.get_json()
    text = data.get('text', '')

    if not text:
        return jsonify({'success': False, 'message': '内容为空'}), 400

    is_spam, score, reasons, llm_result = spam_detector.predict(text)
    return jsonify({
        'success': True,
        'is_spam': is_spam,
        'score': score,
        'reasons': reasons,
        'llm_analysis': llm_result,
    })


# ==================== 预警系统 ====================

@app.route('/api/warnings/<int:user_id>', methods=['GET'])
def api_warnings(user_id):
    warnings = get_warnings(user_id)
    return jsonify({'success': True, 'warnings': warnings})


@app.route('/api/warnings/<int:warning_id>/read', methods=['POST'])
def api_mark_warning(warning_id):
    mark_warning_read(warning_id)
    return jsonify({'success': True, 'message': '已标记为已读'})


# ==================== 统计 ====================

@app.route('/api/stats/<int:user_id>', methods=['GET'])
def api_stats(user_id):
    stats = get_spam_stats(user_id)
    return jsonify({'success': True, 'stats': stats})


# ==================== 用户 ====================

@app.route('/api/users', methods=['GET'])
def api_users():
    users = get_all_users()
    return jsonify({'success': True, 'users': users})


# ==================== 外部邮件接收（模拟） ====================

@app.route('/api/external/receive', methods=['POST'])
def api_external_receive():
    """模拟从外部邮件系统接收邮件（用于测试和演示）"""
    data = request.get_json()
    sender_name = data.get('sender_name', 'external@mail.com')
    receiver_id = data.get('receiver_id')
    subject = data.get('subject', '')
    content = data.get('content', '')

    if not receiver_id or not subject:
        return jsonify({'success': False, 'message': '缺少必要参数'}), 400

    # 查找或创建外部发件人
    users = get_all_users()
    sender = next((u for u in users if u['username'] == sender_name), None)
    if sender is None:
        from database import create_user
        import secrets
        sender_id = create_user(sender_name, secrets.token_hex(8))
    else:
        sender_id = sender['id']

    # 检测垃圾邮件
    full_text = f'{subject} {content}'
    is_spam, spam_score, reasons, llm_result = spam_detector.predict(full_text, subject)

    email_id = save_email(sender_id, receiver_id, subject, content, is_spam=1 if is_spam else 0, spam_score=spam_score)

    result = {
        'success': True,
        'email_id': email_id,
        'is_spam': is_spam,
        'spam_score': spam_score,
        'reasons': reasons,
        'llm_analysis': llm_result,
    }

    if is_spam:
        mark_as_spam(email_id)
        warning_msg = f'收到来自 {sender_name} 的疑似垃圾邮件，主题: "{subject[:50]}"，已自动拦截'
        create_warning(receiver_id, 'spam_detected', warning_msg)
        result['warning'] = warning_msg

    return jsonify(result)


# ==================== LLM API 设置 ====================

@app.route('/api/llm/status', methods=['GET'])
def api_llm_status():
    """获取 LLM API 状态"""
    from config import ENABLE_LLM, DEEPSEEK_API_KEY
    return jsonify({
        'success': True,
        'enabled': ENABLE_LLM,
        'has_key': bool(DEEPSEEK_API_KEY),
        'model': 'deepseek-chat' if ENABLE_LLM else None,
    })


@app.route('/api/llm/config', methods=['POST'])
def api_llm_config():
    """动态设置 DeepSeek API Key（运行时生效，不持久化）"""
    data = request.get_json()
    api_key = data.get('api_key', '').strip()

    if not api_key:
        return jsonify({'success': False, 'message': 'API Key 不能为空'}), 400

    import config
    config.DEEPSEEK_API_KEY = api_key
    config.ENABLE_LLM = True

    return jsonify({
        'success': True,
        'message': 'DeepSeek API Key 已设置，LLM 智能分析已启用',
    })


@app.route('/api/llm/test', methods=['POST'])
def api_llm_test():
    """测试 LLM API 连接"""
    from config import ENABLE_LLM, DEEPSEEK_API_KEY
    if not DEEPSEEK_API_KEY:
        return jsonify({'success': False, 'message': '请先设置 API Key'}), 400

    try:
        from deepseek_client import _call_deepseek_api
        response = _call_deepseek_api([
            {'role': 'user', 'content': '回复"OK"即可'}
        ], temperature=0, max_tokens=10)
        return jsonify({'success': True, 'message': f'连接成功！DeepSeek API 正常响应', 'response': response})
    except Exception as e:
        return jsonify({'success': False, 'message': f'连接失败: {str(e)}'}), 500


# ==================== 启动 ====================

if __name__ == '__main__':
    init_db()
    spam_detector.save_model()
    print('智能反垃圾邮件识别系统启动成功！')
    print('访问地址: http://127.0.0.1:5000')
    app.run(host='0.0.0.0', port=5000, debug=True)
