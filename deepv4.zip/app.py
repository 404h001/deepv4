import os
import json
from datetime import datetime
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

from config import SECRET_KEY, UPLOAD_FOLDER, FACE_DIR
from database import (
    init_db, create_user, verify_user, get_user_by_id,
    save_email, get_inbox, get_sent_emails, get_spam_emails,
    mark_as_spam, restore_from_spam, delete_email, get_email_by_id,
    create_warning, get_warnings, mark_warning_read, get_spam_stats,
    get_all_users,
)
from spam_model import spam_detector
from face_model import register_face, verify_face, has_face_registered, FACE_REC_AVAILABLE
from smart_features import classify_email, summarize_email, detect_sensitive_info, scan_cleanup
from advanced_detection import (
    detect_fraud_patterns, detect_identity_spoof,
    scan_urls, scan_attachment, learn_user_preferences, apply_personalized_adjustment,
)
from ai_assistant import (
    generate_reply_suggestions, analyze_sentiment, extract_todos, polish_email, generate_template,
)

app = Flask(__name__, static_folder='frontend', static_url_path='')
app.secret_key = SECRET_KEY
CORS(app)


@app.route('/')
def index():
    return send_from_directory('frontend', 'index.html')


# ==================== 用户认证 ====================

@app.route('/api/register', methods=['POST'])
def api_register():
    data = request.get_json()
    username = data.get('username', '').strip()
    password = data.get('password', '').strip()

    if not username or not password:
        return jsonify({'success': False, 'message': '用户名和密码不能为空'}), 400
    if len(username) < 3:
        return jsonify({'success': False, 'message': '用户名至少3个字符'}), 400
    if len(password) < 6:
        return jsonify({'success': False, 'message': '密码至少6个字符'}), 400

    user_id = create_user(username, password)
    if user_id is None:
        return jsonify({'success': False, 'message': '用户名已存在'}), 400

    return jsonify({'success': True, 'message': '注册成功', 'user_id': user_id})


@app.route('/api/login', methods=['POST'])
def api_login():
    data = request.get_json()
    username = data.get('username', '').strip()
    password = data.get('password', '').strip()

    user = verify_user(username, password)
    if user is None:
        return jsonify({'success': False, 'message': '用户名或密码错误'}), 401

    return jsonify({
        'success': True,
        'message': '登录成功',
        'user': {'id': user['id'], 'username': user['username']}
    })


@app.route('/api/login/face', methods=['POST'])
def api_face_login():
    data = request.get_json()
    username = data.get('username', '').strip()
    face_image = data.get('face_image', '')

    if not username or not face_image:
        return jsonify({'success': False, 'message': '缺少用户名或人脸图像'}), 400

    if not FACE_REC_AVAILABLE:
        return jsonify({'success': False, 'message': '人脸识别服务暂不可用'}), 503

    success, message, user_id = verify_face(face_image, username)
    if not success:
        return jsonify({'success': False, 'message': message}), 401

    return jsonify({
        'success': True,
        'message': '人脸验证成功',
        'user': {'id': user_id, 'username': username}
    })


@app.route('/api/face/register', methods=['POST'])
def api_register_face():
    data = request.get_json()
    user_id = data.get('user_id')
    face_image = data.get('face_image', '')

    if not user_id or not face_image:
        return jsonify({'success': False, 'message': '缺少参数'}), 400
    if not FACE_REC_AVAILABLE:
        return jsonify({'success': False, 'message': '人脸识别服务暂不可用'}), 503

    success, message = register_face(user_id, face_image)
    return jsonify({'success': success, 'message': message})


@app.route('/api/face/status/<username>', methods=['GET'])
def api_face_status(username):
    registered = has_face_registered(username)
    return jsonify({'has_face': registered, 'available': FACE_REC_AVAILABLE})


# ==================== 邮件操作 ====================

@app.route('/api/emails/send', methods=['POST'])
def api_send_email():
    data = request.get_json()
    sender_id = data.get('sender_id')
    receiver_id = data.get('receiver_id')
    subject = data.get('subject', '').strip()
    content = data.get('content', '').strip()

    if not all([sender_id, receiver_id, subject, content]):
        return jsonify({'success': False, 'message': '请填写完整邮件信息'}), 400

    # 先检测发送内容是否为垃圾内容
    full_text = f'{subject} {content}'
    is_spam, spam_score, reasons, llm_result = spam_detector.predict(full_text, subject)

    # AI智能识别：如果检测为垃圾邮件，仍允许发送，但自动归入收件人垃圾箱
    email_id = save_email(sender_id, receiver_id, subject, content,
                          is_spam=1 if is_spam else 0, spam_score=spam_score)

    response_data = {
        'success': True,
        'message': '邮件发送成功',
        'email_id': email_id,
        'spam_check': {'is_spam': is_spam, 'score': spam_score, 'reasons': reasons},
        'llm_analysis': llm_result,
    }

    if is_spam:
        mark_as_spam(email_id)
        sender_info = get_user_by_id(sender_id)
        sender_name = sender_info['username'] if sender_info else '未知'
        warning_msg = f'AI智能识别：来自 {sender_name} 的邮件被检测为垃圾邮件（评分: {spam_score:.0%}），已自动归入垃圾箱'
        create_warning(receiver_id, 'spam_detected', warning_msg)
        response_data['warning'] = warning_msg

    return jsonify(response_data)


@app.route('/api/emails/receive', methods=['POST'])
def api_receive_email():
    """模拟接收外部邮件"""
    data = request.get_json()
    sender_id = data.get('sender_id')
    receiver_id = data.get('receiver_id')
    subject = data.get('subject', '').strip()
    content = data.get('content', '').strip()

    if not all([sender_id, receiver_id, subject]):
        return jsonify({'success': False, 'message': '缺少邮件信息'}), 400

    # 垃圾邮件检测
    full_text = f'{subject} {content}'
    is_spam, spam_score, reasons, llm_result = spam_detector.predict(full_text, subject)

    email_id = save_email(sender_id, receiver_id, subject, content, is_spam=1 if is_spam else 0, spam_score=spam_score)

    response_data = {
        'success': True,
        'message': '邮件接收成功',
        'email_id': email_id,
    }

    if is_spam:
        mark_as_spam(email_id)
        # 创建预警
        try:
            sender = get_user_by_id(sender_id)
            sender_name = sender['username'] if sender else '未知'
        except Exception:
            sender_name = '未知'
        warning_msg = f'检测到来自 {sender_name} 的垃圾邮件，主题: "{subject[:30]}"，已自动拦截到垃圾箱'
        create_warning(receiver_id, 'spam_detected', warning_msg)
        response_data.update({
            'spam_filtered': True,
            'spam_score': spam_score,
            'reasons': reasons,
            'warning': warning_msg,
            'llm_analysis': llm_result,
        })

    response_data['llm_analysis'] = llm_result
    return jsonify(response_data)


@app.route('/api/emails/inbox/<int:user_id>', methods=['GET'])
def api_inbox(user_id):
    emails = get_inbox(user_id)
    return jsonify({'success': True, 'emails': emails})


@app.route('/api/emails/sent/<int:user_id>', methods=['GET'])
def api_sent(user_id):
    emails = get_sent_emails(user_id)
    return jsonify({'success': True, 'emails': emails})


@app.route('/api/emails/spam/<int:user_id>', methods=['GET'])
def api_spam(user_id):
    emails = get_spam_emails(user_id)
    return jsonify({'success': True, 'emails': emails})


@app.route('/api/emails/<int:email_id>', methods=['GET'])
def api_email_detail(email_id):
    email = get_email_by_id(email_id)
    if not email:
        return jsonify({'success': False, 'message': '邮件不存在'}), 404
    return jsonify({'success': True, 'email': email})


@app.route('/api/emails/<int:email_id>/mark-spam', methods=['POST'])
def api_mark_spam(email_id):
    mark_as_spam(email_id)
    return jsonify({'success': True, 'message': '已标记为垃圾邮件'})


@app.route('/api/emails/<int:email_id>/restore', methods=['POST'])
def api_restore(email_id):
    restore_from_spam(email_id)
    return jsonify({'success': True, 'message': '已恢复为正常邮件'})


@app.route('/api/emails/<int:email_id>/delete', methods=['POST'])
def api_delete(email_id):
    delete_email(email_id)
    return jsonify({'success': True, 'message': '邮件已删除'})


# ==================== 内容检测 ====================

@app.route('/api/check-content', methods=['POST'])
def api_check_content():
    """实时检测文本内容是否为垃圾内容"""
    data = request.get_json()
    text = data.get('text', '')

    if not text:
        return jsonify({'success': False, 'message': '内容为空'}), 400

    is_spam, score, reasons, llm_result = spam_detector.predict(text)
    return jsonify({
        'success': True,
        'is_spam': is_spam,
        'score': score,
        'reasons': reasons,
        'llm_analysis': llm_result,
    })


# ==================== 预警系统 ====================

@app.route('/api/warnings/<int:user_id>', methods=['GET'])
def api_warnings(user_id):
    warnings = get_warnings(user_id)
    return jsonify({'success': True, 'warnings': warnings})


@app.route('/api/warnings/<int:warning_id>/read', methods=['POST'])
def api_mark_warning(warning_id):
    mark_warning_read(warning_id)
    return jsonify({'success': True, 'message': '已标记为已读'})


# ==================== 统计 ====================

@app.route('/api/stats/<int:user_id>', methods=['GET'])
def api_stats(user_id):
    stats = get_spam_stats(user_id)
    return jsonify({'success': True, 'stats': stats})


# ==================== 用户 ====================

@app.route('/api/users', methods=['GET'])
def api_users():
    users = get_all_users()
    return jsonify({'success': True, 'users': users})


# ==================== 外部邮件接收（模拟） ====================

@app.route('/api/external/receive', methods=['POST'])
def api_external_receive():
    """模拟从外部邮件系统接收邮件（用于测试和演示）"""
    data = request.get_json()
    sender_name = data.get('sender_name', 'external@mail.com')
    receiver_id = data.get('receiver_id')
    subject = data.get('subject', '')
    content = data.get('content', '')

    if not receiver_id or not subject:
        return jsonify({'success': False, 'message': '缺少必要参数'}), 400

    # 查找或创建外部发件人
    users = get_all_users()
    sender = next((u for u in users if u['username'] == sender_name), None)
    if sender is None:
        from database import create_user
        import secrets
        sender_id = create_user(sender_name, secrets.token_hex(8))
    else:
        sender_id = sender['id']

    # 检测垃圾邮件
    full_text = f'{subject} {content}'
    is_spam, spam_score, reasons, llm_result = spam_detector.predict(full_text, subject)

    email_id = save_email(sender_id, receiver_id, subject, content, is_spam=1 if is_spam else 0, spam_score=spam_score)

    result = {
        'success': True,
        'email_id': email_id,
        'is_spam': is_spam,
        'spam_score': spam_score,
        'reasons': reasons,
        'llm_analysis': llm_result,
    }

    if is_spam:
        mark_as_spam(email_id)
        warning_msg = f'收到来自 {sender_name} 的疑似垃圾邮件，主题: "{subject[:50]}"，已自动拦截'
        create_warning(receiver_id, 'spam_detected', warning_msg)
        result['warning'] = warning_msg

    return jsonify(result)


# ==================== LLM API 设置 ====================

@app.route('/api/llm/status', methods=['GET'])
def api_llm_status():
    """获取 LLM API 状态"""
    from config import ENABLE_LLM, DEEPSEEK_API_KEY
    return jsonify({
        'success': True,
        'enabled': ENABLE_LLM,
        'has_key': bool(DEEPSEEK_API_KEY),
        'model': 'deepseek-chat' if ENABLE_LLM else None,
    })


@app.route('/api/llm/config', methods=['POST'])
def api_llm_config():
    """动态设置 DeepSeek API Key（运行时生效，不持久化）"""
    data = request.get_json()
    api_key = data.get('api_key', '').strip()

    if not api_key:
        return jsonify({'success': False, 'message': 'API Key 不能为空'}), 400

    import config
    config.DEEPSEEK_API_KEY = api_key
    config.ENABLE_LLM = True

    return jsonify({
        'success': True,
        'message': 'DeepSeek API Key 已设置，LLM 智能分析已启用',
    })


@app.route('/api/llm/test', methods=['POST'])
def api_llm_test():
    """测试 LLM API 连接"""
    from config import ENABLE_LLM, DEEPSEEK_API_KEY
    if not DEEPSEEK_API_KEY:
        return jsonify({'success': False, 'message': '请先设置 API Key'}), 400

    try:
        from deepseek_client import _call_deepseek_api
        response = _call_deepseek_api([
            {'role': 'user', 'content': '回复"OK"即可'}
        ], temperature=0, max_tokens=10)
        return jsonify({'success': True, 'message': f'连接成功！DeepSeek API 正常响应', 'response': response})
    except Exception as e:
        return jsonify({'success': False, 'message': f'连接失败: {str(e)}'}), 500


# ==================== 智能分类与摘要 ====================

@app.route('/api/emails/classify', methods=['POST'])
def api_classify_email():
    """对邮件进行智能分类"""
    data = request.get_json()
    subject = data.get('subject', '')
    content = data.get('content', '')

    if not subject and not content:
        return jsonify({'success': False, 'message': '缺少邮件内容'}), 400

    result = classify_email(subject, content)
    return jsonify({'success': True, **result})


@app.route('/api/emails/summarize', methods=['POST'])
def api_summarize_email():
    """对长邮件生成智能摘要"""
    data = request.get_json()
    subject = data.get('subject', '')
    content = data.get('content', '')

    if not content:
        return jsonify({'success': False, 'message': '缺少邮件内容'}), 400

    summary = summarize_email(subject, content)
    return jsonify({'success': True, 'summary': summary})


# ==================== 敏感信息检测 ====================

@app.route('/api/emails/check-sensitive', methods=['POST'])
def api_check_sensitive():
    """检测邮件中的敏感信息"""
    data = request.get_json()
    subject = data.get('subject', '')
    content = data.get('content', '')

    result = detect_sensitive_info(subject, content)
    return jsonify({'success': True, **result})


# ==================== 智能批量清理 ====================

@app.route('/api/emails/cleanup-scan/<int:user_id>', methods=['GET'])
def api_cleanup_scan(user_id):
    """扫描全邮箱，生成清理建议"""
    from database import get_db

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT e.*, u.username as sender_name
        FROM emails e JOIN users u ON e.sender_id = u.id
        WHERE e.receiver_id = ? AND e.is_deleted = 0
        ORDER BY e.created_at DESC
    ''', (user_id,))
    emails = [dict(row) for row in cursor.fetchall()]
    conn.close()

    result = scan_cleanup(user_id, emails)
    return jsonify({'success': True, **result})


@app.route('/api/emails/batch-action', methods=['POST'])
def api_batch_action():
    """批量操作邮件（删除/标记垃圾）"""
    data = request.get_json()
    email_ids = data.get('email_ids', [])
    action = data.get('action', 'delete')  # delete 或 mark-spam

    if not email_ids:
        return jsonify({'success': False, 'message': '请选择邮件'}), 400

    count = 0
    for eid in email_ids:
        try:
            if action == 'delete':
                from database import delete_email
                delete_email(eid)
            elif action == 'mark-spam':
                from database import mark_as_spam
                mark_as_spam(eid)
            count += 1
        except Exception:
            pass

    return jsonify({'success': True, 'message': f'已处理 {count} 封邮件', 'count': count})


# ==================== 高级 AI 检测 ====================

@app.route('/api/detect/fraud', methods=['POST'])
def api_detect_fraud():
    """语义级诈骗套路识别"""
    data = request.get_json()
    subject = data.get('subject', '')
    content = data.get('content', '')

    if not content:
        return jsonify({'success': False, 'message': '缺少内容'}), 400

    result = detect_fraud_patterns(subject, content)
    return jsonify({'success': True, **result})


@app.route('/api/detect/identity', methods=['POST'])
def api_detect_identity():
    """发件人身份伪造检测"""
    data = request.get_json()
    sender_email = data.get('sender_email', '')
    sender_name = data.get('sender_name', '')
    subject = data.get('subject', '')
    content = data.get('content', '')
    sender_id = data.get('sender_id')

    # 获取发件人的历史邮件用于语气比对
    historical = []
    if sender_id:
        try:
            from database import get_db
            conn = get_db()
            cursor = conn.cursor()
            cursor.execute(
                'SELECT subject, content FROM emails WHERE sender_id = ? AND is_spam = 0 ORDER BY created_at DESC LIMIT 5',
                (sender_id,))
            historical = [dict(row) for row in cursor.fetchall()]
            conn.close()
        except Exception:
            pass

    result = detect_identity_spoof(sender_email, sender_name, subject, content, historical)
    return jsonify({'success': True, **result})


@app.route('/api/detect/scan-urls', methods=['POST'])
def api_scan_urls():
    """链接深度风险扫描"""
    data = request.get_json()
    text = data.get('text', '')
    if not text:
        return jsonify({'success': False, 'message': '缺少内容'}), 400
    result = scan_urls(text)
    return jsonify({'success': True, **result})


@app.route('/api/detect/scan-attachment', methods=['POST'])
def api_scan_attachment():
    """附件风险扫描"""
    data = request.get_json()
    filename = data.get('filename', '')
    file_ext = data.get('extension', '')
    result = scan_attachment(filename, file_ext)
    return jsonify({'success': True, **result})


@app.route('/api/detect/personalize/<int:user_id>', methods=['GET'])
def api_personalize(user_id):
    """获取用户个性化检测模型"""
    profile = learn_user_preferences(user_id)
    return jsonify({'success': True, 'profile': profile})


# 综合性深度检测（供发送时一次性调用）
@app.route('/api/detect/comprehensive', methods=['POST'])
def api_comprehensive_detect():
    """综合深度检测：诈骗 + 身份 + 链接 + 附件"""
    data = request.get_json()
    subject = data.get('subject', '')
    content = data.get('content', '')
    sender_email = data.get('sender_email', '')
    sender_name = data.get('sender_name', '')
    sender_id = data.get('sender_id')

    result = {
        'success': True,
        'fraud': None,
        'identity': None,
        'urls': None,
        'warnings': [],
        'overall_risk': '安全',
    }

    # 诈骗检测
    if content:
        try:
            result['fraud'] = detect_fraud_patterns(subject, content)
            if result['fraud'].get('is_fraud'):
                result['warnings'].append(f"诈骗预警: {result['fraud'].get('fraud_type')}")
        except Exception as e:
            result['fraud'] = {'error': str(e)[:50]}

    # 身份伪造
    if sender_email:
        try:
            historical = []
            if sender_id:
                from database import get_db
                conn = get_db()
                cur = conn.cursor()
                cur.execute(
                    'SELECT subject, content FROM emails WHERE sender_id=? AND is_spam=0 ORDER BY created_at DESC LIMIT 3',
                    (sender_id,))
                historical = [dict(r) for r in cur.fetchall()]
                conn.close()
            result['identity'] = detect_identity_spoof(sender_email, sender_name, subject, content, historical)
            if result['identity'].get('is_suspicious'):
                result['warnings'].extend(result['identity'].get('reasons', []))
        except Exception as e:
            result['identity'] = {'error': str(e)[:50]}

    # 链接扫描
    if content:
        try:
            result['urls'] = scan_urls(content)
            if result['urls'].get('warnings'):
                result['warnings'].extend(result['urls']['warnings'])
        except Exception as e:
            result['urls'] = {'error': str(e)[:50]}

    # 综合风险
    risk_score = 0.0
    if result.get('fraud') and result['fraud'].get('risk_score'):
        risk_score = max(risk_score, result['fraud']['risk_score'])
    if result.get('identity') and result['identity'].get('risk_level') in ('高风险', '中风险'):
        risk_score = max(risk_score, 0.7 if result['identity']['risk_level'] == '高风险' else 0.5)
    if result.get('urls') and result['urls'].get('risk_score', 0) > 0.5:
        risk_score = max(risk_score, result['urls']['risk_score'])

    if risk_score >= 0.7:
        result['overall_risk'] = '高风险'
    elif risk_score >= 0.4:
        result['overall_risk'] = '中风险'

    return jsonify(result)


# ==================== AI 增强助手 ====================

@app.route('/api/ai/reply-suggestions', methods=['POST'])
def api_reply_suggestions():
    """AI 生成邮件回复建议"""
    data = request.get_json()
    result = generate_reply_suggestions(
        data.get('subject', ''),
        data.get('content', ''),
        data.get('sender_name', ''),
    )
    return jsonify(result)


@app.route('/api/ai/sentiment', methods=['POST'])
def api_sentiment():
    """邮件情感与紧急度分析"""
    data = request.get_json()
    result = analyze_sentiment(
        data.get('subject', ''),
        data.get('content', ''),
    )
    return jsonify(result)


@app.route('/api/ai/extract-todos', methods=['POST'])
def api_extract_todos():
    """从邮件中提取日程待办"""
    data = request.get_json()
    result = extract_todos(
        data.get('subject', ''),
        data.get('content', ''),
    )
    return jsonify(result)


@app.route('/api/ai/polish', methods=['POST'])
def api_polish_email():
    """AI 润色邮件"""
    data = request.get_json()
    result = polish_email(
        data.get('content', ''),
        data.get('style', 'professional'),
    )
    return jsonify(result)


@app.route('/api/ai/template', methods=['POST'])
def api_template():
    """AI 生成邮件模板"""
    data = request.get_json()
    purpose = data.get('purpose', '请假申请')
    result = generate_template(purpose)
    return jsonify(result)


@app.route('/api/ai/summarize-text', methods=['POST'])
def api_summarize_text():
    """AI 页面/文本内容总结"""
    data = request.get_json()
    text = data.get('text', '').strip()
    if not text or len(text) < 50:
        return jsonify({'success': False, 'message': '文本太短'}), 400

    try:
        from deepseek_client import _call_deepseek_api
        prompt = f"""请用简洁中文（50-80字）总结以下网页内容的核心主题和关键信息。直接返回总结文字不要JSON：

{text[:2500]}"""
        summary = _call_deepseek_api([{'role': 'user', 'content': prompt}], temperature=0.2, max_tokens=150)
        return jsonify({'success': True, 'summary': summary.strip()})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)[:80]})


@app.route('/api/ai/translate', methods=['POST'])
def api_translate():
    """AI 翻译：逐行对照，支持英→中、中→英"""
    data = request.get_json()
    text = data.get('text', '').strip()
    direction = data.get('direction', 'auto')  # auto / en2zh / zh2en

    if not text:
        return jsonify({'success': False, 'message': '缺少文本'}), 400

    # 自动检测语言方向
    if direction == 'auto':
        ascii_count = sum(1 for c in text if c.isascii() and c.isalpha())
        total_alpha = sum(1 for c in text if c.isalpha())
        if total_alpha > 0 and ascii_count / total_alpha > 0.6:
            direction = 'en2zh'
        else:
            direction = 'zh2en'

    prompt_en2zh = f"""请将以下英文逐行翻译成中文。要求：
1. 逐行对照翻译，保持原文换行
2. 翻译严谨准确，专业术语保持一致性
3. 每行格式：中文翻译   （不要保留原文，不要编号，直接翻译）

原文：
{text[:2000]}"""

    prompt_zh2en = f"""Translate the following Chinese text into English line by line. Requirements:
1. Line-by-line translation, preserve original line breaks
2. Professional and accurate translation
3. Format: English translation only per line (no numbering, no original text)

原文：
{text[:2000]}"""

    try:
        from deepseek_client import _call_deepseek_api
        prompt = prompt_en2zh if direction == 'en2zh' else prompt_zh2en
        translated = _call_deepseek_api(
            [{'role': 'user', 'content': prompt}],
            temperature=0.1, max_tokens=1500
        )
        return jsonify({
            'success': True,
            'translated': translated.strip(),
            'direction': direction,
            'original': text,
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)[:80]})


# ==================== AI 仪表盘智能解读 ====================

@app.route('/api/ai/dashboard-insights/<int:user_id>', methods=['GET'])
def api_dashboard_insights(user_id):
    """AI 仪表盘智能解读：分组 + 趋势 + 洞察"""
    from database import get_db

    conn = get_db()
    cursor = conn.cursor()

    # 获取所有邮件
    cursor.execute('''
        SELECT e.*, u.username as sender_name
        FROM emails e JOIN users u ON e.sender_id = u.id
        WHERE e.receiver_id = ? AND e.is_deleted = 0
        ORDER BY e.created_at DESC LIMIT 50
    ''', (user_id,))
    emails = [dict(row) for row in cursor.fetchall()]

    # 用户行为数据
    cursor.execute('SELECT COUNT(*) as cnt FROM spam_log WHERE email_id IN (SELECT id FROM emails WHERE receiver_id=?)', (user_id,))
    spam_logged = cursor.fetchone()['cnt']

    conn.close()

    # 本地分组统计
    groups = {}
    for e in emails[:30]:
        cat = classify_email(e.get('subject',''), e.get('content',''))['category']
        if cat not in groups:
            groups[cat] = {'count': 0, 'unread': 0, 'latest': ''}
        groups[cat]['count'] += 1
        groups[cat]['latest'] = e.get('subject', '')[:30] if not groups[cat]['latest'] else groups[cat]['latest']

    # AI 智能解读
    spam_emails = [e for e in emails if e.get('is_spam')]
    normal_emails = [e for e in emails if not e.get('is_spam')]

    subjects_sample = [e.get('subject','') for e in normal_emails[:8] if e.get('subject')]
    spam_subjects_sample = [e.get('subject','') for e in spam_emails[:3] if e.get('subject')]

    total_all = len(emails)
    spam_ratio = len(spam_emails) / max(1, total_all) * 100

    # 用 DeepSeek 生成智能解读
    insight_text = ''
    try:
        from deepseek_client import _call_deepseek_api
        prompt = f"""你是邮件安全分析师。用户的邮箱状态如下：
- 总邮件数(近50封): {total_all}
- 正常: {len(normal_emails)} 封，垃圾: {len(spam_emails)} 封 (占比{spam_ratio:.0f}%)
- 用户手动阻止过 {spam_logged} 封
- 最近正常邮件主题: {subjects_sample[:5]}
- 最近垃圾主题: {spam_subjects_sample[:3]}

请用简短中文(50字内)给出一条智能邮箱洞察，例如关注趋势、异常或安全建议。直接返回文字不要JSON。"""
        insight_text = _call_deepseek_api(
            [{'role': 'user', 'content': prompt}],
            temperature=0.4, max_tokens=80
        ).strip().strip('"')
    except:
        insight_text = f'当前拦截率 {spam_ratio:.0f}%，共 {len(spam_emails)} 封垃圾被自动过滤'

    return jsonify({
        'success': True,
        'groups': [{'name': k, **v} for k, v in sorted(groups.items(), key=lambda x: -x[1]['count'])],
        'insight': insight_text,
        'spam_ratio': round(spam_ratio, 1),
        'total_scanned': total_all,
        'spam_logged': spam_logged,
    })


# ==================== 启动 ====================

if __name__ == '__main__':
    init_db()
    spam_detector.save_model()
    print('智能反垃圾邮件识别系统启动成功！')
    print('访问地址: http://127.0.0.1:5000')
    app.run(host='0.0.0.0', port=5000, debug=True)
