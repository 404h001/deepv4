"""智能功能模块：邮件分类、摘要、敏感信息检测、批量清理"""
import json
import re
from deepseek_client import _call_deepseek_api


# ==================== 1. 邮件智能分类 + 摘要 ====================

CATEGORIES = ['工作通知', '个人邮件', '订阅推广', '验证码', '物流通知', '账单财务', '社交互动', '系统通知', '其他']


def classify_email(subject, content):
    """用 DeepSeek 对邮件自动分类"""
    try:
        prompt = f"""分析以下邮件，判断其最可能的类别。
可选类别: {', '.join(CATEGORIES)}

邮件主题: {subject}
邮件内容: {content[:800]}

请严格返回JSON: {{"category": "类别名称", "confidence": 0.0-1.0}}"""

        response = _call_deepseek_api([
            {'role': 'user', 'content': prompt}
        ], temperature=0, max_tokens=100)

        result = json.loads(_extract_json(response))
        return {
            'category': result.get('category', '其他'),
            'confidence': float(result.get('confidence', 0.5)),
        }
    except Exception:
        return _local_classify(subject, content)


def _local_classify(subject, content):
    """本地规则分类（LLM 不可用时的回退）"""
    text = f'{subject} {content}'.lower()
    rules = [
        (['验证码', '验证', 'verification code', 'code:', 'otp'], '验证码'),
        (['快递', '物流', '包裹', '发货', '运输', '订单号', '运单'], '物流通知'),
        (['会议', '开会', '周报', '述职', '审批', '报销', '考勤', '通知', '公告'], '工作通知'),
        (['订阅', 'newsletter', '订阅', '退订', 'unsubscribe', '促销', '优惠'], '订阅推广'),
        (['账单', '发票', '付款', '支付', '缴费', '充值', '账单', 'invoice'], '账单财务'),
        (['评论', '点赞', '关注', '好友', '私信', '回复了', '@'], '社交互动'),
        (['系统', '更新', '升级', '维护', '安全提醒', '登录通知'], '系统通知'),
    ]
    for keywords, category in rules:
        if any(kw.lower() in text for kw in keywords):
            return {'category': category, 'confidence': 0.7}
    return {'category': '其他', 'confidence': 0.5}


def summarize_email(subject, content):
    """用 DeepSeek 生成长邮件摘要（100 字以内）"""
    full_text = f'主题: {subject}\n内容: {content}'
    if len(full_text) < 200:
        return content[:100] if content else subject

    try:
        prompt = f"""请将以下邮件内容总结为100字以内的核心摘要，保留关键信息：

{full_text[:2000]}

请严格返回JSON: {{"summary": "摘要内容"}}"""

        response = _call_deepseek_api([
            {'role': 'user', 'content': prompt}
        ], temperature=0.2, max_tokens=200)

        result = json.loads(_extract_json(response))
        return result.get('summary', content[:100])
    except Exception:
        return content[:100] + ('...' if len(content) > 100 else '')


def _extract_json(text):
    """从文本中提取 JSON 部分"""
    match = re.search(r'\{[\s\S]*\}', text)
    return match.group() if match else '{}'


# ==================== 2. 敏感信息检测 ====================

SENSITIVE_PATTERNS = {
    '身份证号': r'[1-9]\d{5}(19|20)\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])\d{3}[\dXx]',
    '手机号': r'1[3-9]\d{9}',
    '银行卡号': r'\d{16,19}',
    '邮箱地址': r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
    '密码': r'(?:密码|password|pwd|pass)[\s:：=]+\S{3,30}',
    'IP地址': r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}',
}

SENSITIVE_KEYWORDS = [
    '密码', 'password', 'pwd', '密钥', 'secret', 'token', 'api.?key',
    '内部', '机密', '保密', 'confidential', 'internal only',
    '身份证', '护照', '驾照', '社保', '公积金',
    '银行卡', '信用卡', '银行账号', '卡号', 'cvv',
]


def detect_sensitive_info(subject, content):
    """检测邮件中的敏感信息

    返回: {found: bool, items: [...], risk_level: str}
    """
    full_text = f'{subject}\n{content}'
    found_items = []

    # 正则匹配
    for label, pattern in SENSITIVE_PATTERNS.items():
        matches = re.findall(pattern, full_text, re.IGNORECASE)
        if matches:
            # 脱敏显示
            masked = [_mask_value(m, label) for m in matches[:3]]
            found_items.append({
                'type': label,
                'count': len(matches),
                'sample': masked,
            })

    # 关键词匹配
    kw_matches = []
    for kw in SENSITIVE_KEYWORDS:
        pattern = re.compile(kw, re.IGNORECASE)
        if pattern.search(full_text):
            kw_matches.append(kw)
    if kw_matches:
        found_items.append({
            'type': '敏感关键词',
            'count': len(kw_matches),
            'sample': kw_matches[:5],
        })

    if not found_items:
        return {'found': False, 'items': [], 'risk_level': '安全'}

    # 风险评估
    total_count = sum(item['count'] for item in found_items)
    if total_count >= 5 or any(i['type'] in ['身份证号', '密码'] for i in found_items):
        risk_level = '高风险'
    elif total_count >= 2:
        risk_level = '中风险'
    else:
        risk_level = '低风险'

    return {
        'found': True,
        'items': found_items,
        'risk_level': risk_level,
        'total_count': total_count,
    }


def _mask_value(value, item_type):
    """脱敏处理"""
    if item_type == '身份证号' and len(value) >= 18:
        return value[:3] + '****' + value[-4:]
    elif item_type == '手机号' and len(value) == 11:
        return value[:3] + '****' + value[-4:]
    elif item_type == '银行卡号' and len(value) >= 16:
        return value[:4] + '****' + value[-4:]
    elif item_type == '密码':
        return '******'
    elif item_type == '邮箱地址':
        parts = value.split('@')
        if len(parts) == 2:
            return parts[0][:2] + '***@' + parts[1]
    return '***'


# ==================== 3. 智能批量清理助手 ====================

CLEANUP_RULES = [
    {
        'name': '过期验证码',
        'reason': '验证码类邮件通常1小时内失效，可安全清理',
        'keywords': ['验证码', 'verification', 'code', '激活码', 'otp'],
    },
    {
        'name': '订阅推广',
        'reason': '低价值订阅推广邮件，可选择清理',
        'keywords': ['订阅', '退订', 'unsubscribe', '促销', '优惠券', '限时', '折扣'],
    },
    {
        'name': '系统通知',
        'reason': '重复的系统通知，建议保留最近3条',
        'keywords': ['系统通知', '登录提醒', '密码修改', '异地登录', '安全提醒'],
    },
    {
        'name': '重复邮件',
        'reason': '主题完全相同的重复邮件，保留最新一条即可',
        'keywords': [],  # 特殊处理：按主题去重
    },
]


def scan_cleanup(user_id, emails):
    """扫描全邮箱，生成清理建议

    返回: {categories: [...], total_suggested: int}
    """
    categories = []
    already_matched = set()

    for rule in CLEANUP_RULES:
        if rule['name'] == '重复邮件':
            # 特殊处理：按主题去重
            seen_subjects = {}
            duplicates = []
            for e in emails:
                subj = e.get('subject', '').strip()
                if subj and len(subj) > 3:
                    if subj in seen_subjects:
                        if e['id'] not in already_matched:
                            duplicates.append(e)
                            already_matched.add(e['id'])
                    else:
                        seen_subjects[subj] = e['id']
            if duplicates:
                categories.append({
                    'name': rule['name'],
                    'reason': rule['reason'],
                    'count': len(duplicates),
                    'emails': duplicates,
                })
        else:
            matched = []
            for e in emails:
                if e['id'] in already_matched:
                    continue
                full_text = f"{e.get('subject','')} {e.get('content','')}".lower()
                if any(kw.lower() in full_text for kw in rule['keywords']):
                    matched.append(e)
                    already_matched.add(e['id'])
            if matched:
                categories.append({
                    'name': rule['name'],
                    'reason': rule['reason'],
                    'count': len(matched),
                    'emails': matched,
                })

    total = sum(c['count'] for c in categories)
    return {'categories': categories, 'total_suggested': total}
