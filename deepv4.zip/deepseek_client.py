"""DeepSeek API 客户端 - 用于智能垃圾邮件语义分析"""
import os
import json
import urllib.request
import urllib.error
from config import DEEPSEEK_API_KEY, DEEPSEEK_API_URL, DEEPSEEK_MODEL

# API 调用超时（秒）
API_TIMEOUT = 15


def _call_deepseek_api(messages, temperature=0.1, max_tokens=500):
    """调用 DeepSeek Chat API"""
    if not DEEPSEEK_API_KEY:
        raise ValueError('DeepSeek API Key 未配置')

    data = json.dumps({
        'model': DEEPSEEK_MODEL,
        'messages': messages,
        'temperature': temperature,
        'max_tokens': max_tokens,
        'stream': False,
    }).encode('utf-8')

    req = urllib.request.Request(DEEPSEEK_API_URL, data=data, method='POST')
    req.add_header('Content-Type', 'application/json')
    req.add_header('Authorization', f'Bearer {DEEPSEEK_API_KEY}')

    try:
        with urllib.request.urlopen(req, timeout=API_TIMEOUT) as resp:
            result = json.loads(resp.read().decode('utf-8'))
            return result['choices'][0]['message']['content']
    except urllib.error.HTTPError as e:
        error_body = e.read().decode('utf-8') if e.fp else ''
        raise RuntimeError(f'DeepSeek API 错误 (HTTP {e.code}): {error_body}')
    except Exception as e:
        raise RuntimeError(f'DeepSeek API 调用失败: {str(e)}')


def analyze_spam_with_llm(subject, content):
    """使用 DeepSeek LLM 分析邮件是否为垃圾邮件

    返回: {
        'is_spam': bool,
        'score': float (0.0-1.0),
        'category': str,       # 垃圾邮件类别
        'reasoning': str,      # 分析推理
        'risk_level': str,     # low/medium/high/critical
        'suggestions': str,    # 建议
    }
    """
    email_text = f'主题: {subject}\n\n内容: {content}'

    system_prompt = """你是一个专业的垃圾邮件分析专家。请分析以下邮件内容，判断是否为垃圾邮件。

你需要从以下维度分析：
1. 邮件意图：是否包含推销、诈骗、钓鱼、恶意内容
2. 语言特征：是否使用夸张、紧迫感制造、虚假承诺等操纵性语言
3. 内容真实性：信息是否合理可信
4. 链接与附件：是否包含可疑URL
5. 社会工程学：是否试图诱导收件人采取特定行动

请严格按照以下JSON格式回复，不要包含其他内容：
{
    "is_spam": true或false,
    "score": 0.0到1.0之间的数值（置信度），
    "category": "垃圾邮件类别（普通营销/钓鱼诈骗/恶意软件/赌博色情/虚假中奖/金融诈骗/正常邮件）",
    "reasoning": "简短的分析推理，不超过100字",
    "risk_level": "风险等级（low/medium/high/critical）",
    "suggestions": "如果是垃圾邮件，给出简短的处理建议，不超过50字"
}"""

    messages = [
        {'role': 'system', 'content': system_prompt},
        {'role': 'user', 'content': f'请分析以下邮件：\n\n{email_text}'},
    ]

    try:
        response = _call_deepseek_api(messages, temperature=0.1, max_tokens=500)
        # 解析 JSON 响应
        return _parse_llm_response(response)
    except Exception as e:
        return {
            'is_spam': None,
            'score': 0.0,
            'category': 'API调用失败',
            'reasoning': str(e),
            'risk_level': 'unknown',
            'suggestions': 'LLM分析暂不可用，已回退到本地模型',
            'error': str(e),
        }


def _parse_llm_response(response):
    """解析 LLM 返回的 JSON"""
    try:
        # 尝试直接解析
        result = json.loads(response)
    except json.JSONDecodeError:
        # 尝试提取 JSON 部分
        import re
        match = re.search(r'\{[\s\S]*\}', response)
        if match:
            try:
                result = json.loads(match.group())
            except json.JSONDecodeError:
                return _fallback_parse(response)
        else:
            return _fallback_parse(response)

    return {
        'is_spam': result.get('is_spam', False),
        'score': float(result.get('score', 0.5)),
        'category': result.get('category', '未知'),
        'reasoning': result.get('reasoning', ''),
        'risk_level': result.get('risk_level', 'medium'),
        'suggestions': result.get('suggestions', ''),
    }


def _fallback_parse(response):
    """当 JSON 解析失败时的回退处理"""
    text_lower = response.lower()
    is_spam = any(w in text_lower for w in ['垃圾邮件', 'spam', '钓鱼', '诈骗', 'true', '"is_spam": true'])

    return {
        'is_spam': is_spam,
        'score': 0.7 if is_spam else 0.2,
        'category': 'LLM分析',
        'reasoning': response[:100],
        'risk_level': 'high' if is_spam else 'low',
        'suggestions': '建议人工复核' if is_spam else '',
    }
