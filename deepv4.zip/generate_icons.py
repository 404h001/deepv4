"""简单图标生成脚本 - 为Chrome扩展生成占位图标"""
from PIL import Image, ImageDraw, ImageFont
import os

ICON_DIR = os.path.join(os.path.dirname(__file__), 'extension', 'icons')
os.makedirs(ICON_DIR, exist_ok=True)

def create_icon(size, path):
    img = Image.new('RGBA', (size, size), (79, 70, 229, 255))
    draw = ImageDraw.Draw(img)
    # 画一个简单的盾牌形状
    margin = size // 6
    draw.rectangle([margin, margin, size - margin, size - margin], fill=(255, 255, 255, 255))
    draw.rectangle([size//4, size//4, size*3//4, size*3//4], fill=(79, 70, 229, 255))
    # 画 S 标志
    center = size // 2
    r = size // 6
    draw.ellipse([center - r, center - r, center + r, center + r], fill=(255, 255, 255, 255))
    img.save(path, 'PNG')

for s in [16, 48, 128]:
    create_icon(s, os.path.join(ICON_DIR, f'icon{s}.png'))

print("Icons generated successfully!")
