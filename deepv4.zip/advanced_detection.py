"""高级 AI 检测模块：诈骗识别、身份伪造、链接/附件扫描、个性化学习"""
import re
import json
from deepseek_client import _call_deepseek_api


# ==================== 1. 语义级诈骗套路识别 ====================

FRAUD_SYSTEM_PROMPT = """你是资深网络安全与反诈骗分析专家。请深度分析以下邮件内容，从话术逻辑层面识别诈骗套路。

分析维度:
1. 紧迫感制造: 是否使用"立即/冻结/封禁/紧急/限时/最后机会"等威胁性语言逼迫收件人快速行动
2. 身份冒充: 是否冒用银行/公安/法院/领导/HR/官方平台等权威身份
3. 情感诱导: 是否利用恐惧/贪婪/好奇/同情等情绪操控（杀猪盘、虚假交友、返利诱饵）
4. 信息真实性: 声称的事实是否合理，是否存在逻辑漏洞
5. 钓鱼链接: 是否引导点击可疑链接、扫描二维码、下载附件

请严格返回JSON（不要markdown代码块）:
{
    "is_fraud": true或false,
    "fraud_type": "诈骗类型（紧迫感威胁/身份冒充/情感诱导/钓鱼链接/虚假中奖/虚假客服/杀猪盘/正常邮件）",
    "risk_score": 0.0到1.0,
    "tactics": ["使用的话术手段列表"],
    "reasoning": "分析推理，80字以内",
    "red_flags": ["危险信号列表"]
}"""


def detect_fraud_patterns(subject, content):
    """语义级诈骗套路检测"""
    email_text = f'主题: {subject}\n\n内容: {content[:1500]}'

    try:
        response = _call_deepseek_api([
            {'role': 'system', 'content': FRAUD_SYSTEM_PROMPT},
            {'role': 'user', 'content': f'请分析:\n{email_text}'}
        ], temperature=0.1, max_tokens=600)

        result = json.loads(_extract_json(response))
        return {
            'is_fraud': result.get('is_fraud', False),
            'fraud_type': result.get('fraud_type', '正常邮件'),
            'risk_score': float(result.get('risk_score', 0)),
            'tactics': result.get('tactics', []),
            'reasoning': result.get('reasoning', ''),
            'red_flags': result.get('red_flags', []),
        }
    except Exception as e:
        return {
            'is_fraud': False,
            'fraud_type': '检测异常',
            'risk_score': 0.0,
            'tactics': [],
            'reasoning': f'LLM分析不可用: {str(e)[:60]}',
            'red_flags': ['LLM暂不可用，已回退本地检测'],
        }


# ==================== 2. 发件人身份伪造检测 ====================

TRUSTED_DOMAINS = [
    'apple.com', 'google.com', 'microsoft.com', 'amazon.com', 'paypal.com',
    'qq.com', 'alipay.com', 'weixin.com', 'taobao.com', 'jd.com',
    'icbc.com.cn', 'ccb.com', 'abchina.com', 'boc.cn', 'cmbchina.com',
    'gov.cn', '12306.cn',
]

SPOOF_PATTERNS = [
    r'(secure|login|verify|account|billing|support|service|admin|security)[-\.]',
    r'(apple|google|microsoft|paypal|amazon|alibaba)[-\.](?!com\b|cn\b)\w+',
    r'\w+[-\.](support|service|help|verify|secure|login|account)',
]


def detect_identity_spoof(sender_email, sender_name, subject, content, historical_emails=None):
    """发件人身份伪造检测

    historical_emails: 该发件人的历史正常邮件列表，用于语气比对
    """
    result = {
        'is_suspicious': False,
        'domain_check': {},
        'tone_check': {},
        'risk_level': '安全',
        'reasons': [],
    }

    # 1. 域名相似度检测
    email = sender_email or ''
    if '@' in email:
        domain = email.split('@')[1].lower()
        result['domain_check']['domain'] = domain

        # 检查是否仿冒知名域名
        for trusted in TRUSTED_DOMAINS:
            if _is_spoof_domain(domain, trusted):
                result['domain_check']['spoof_of'] = trusted
                result['domain_check']['is_spoof'] = True
                result['is_suspicious'] = True
                result['reasons'].append(f'域名 {domain} 仿冒 {trusted}')
                break

        # 检查域名是否包含可疑模式
        for pattern in SPOOF_PATTERNS:
            if re.search(pattern, domain, re.IGNORECASE):
                result['domain_check']['suspicious_pattern'] = True
                result['is_suspicious'] = True
                result['reasons'].append(f'域名 "{domain}" 包含钓鱼特征模式')
                break

    # 2. 语气匹配校验
    if sender_name and historical_emails and len(historical_emails) >= 2:
        tone_check = _check_tone_consistency(sender_name, subject, content, historical_emails)
        result['tone_check'] = tone_check
        if tone_check.get('tone_mismatch'):
            result['is_suspicious'] = True
            result['reasons'].append(tone_check['reason'])

    # 风险评估
    reason_count = len(result['reasons'])
    if reason_count >= 2:
        result['risk_level'] = '高风险'
    elif reason_count == 1:
        result['risk_level'] = '中风险'

    return result


def _is_spoof_domain(domain, trusted):
    """检测域名是否仿冒知名域名"""
    if domain == trusted:
        return False
    # 编辑距离检测（替换字符）
    if len(domain) >= len(trusted) - 3 and len(domain) <= len(trusted) + 5:
        # 包含知名域名关键字符
        trusted_core = trusted.split('.')[0]
        if trusted_core.lower() in domain.lower():
            return True
        # 拼写变体检测（替换常见字符）
        variants = trusted.replace('o', '[o0]').replace('l', '[l1i]').replace('i', '[i1l]').replace('e', '[e3]')
        try:
            if re.search(variants, domain, re.IGNORECASE):
                return True
        except:
            pass
    return False


def _check_tone_consistency(sender_name, subject, content, historical_emails):
    """检查语气是否与历史邮件一致"""
    hist_subjects = [e.get('subject', '') for e in historical_emails[:3]]
    hist_text = ' | '.join(hist_subjects)

    prompt = f"""对比两段邮件，判断是否为同一人的语气风格:

发件人声称身份: {sender_name}
当前邮件主题: {subject}
当前邮件内容: {content[:300]}

历史邮件主题: {hist_text}

请返回JSON: {{"tone_match": true或false, "confidence": 0.0-1.0, "reason": "简短理由"}}"""

    try:
        response = _call_deepseek_api([
            {'role': 'user', 'content': prompt}
        ], temperature=0.2, max_tokens=150)
        result = json.loads(_extract_json(response))
        return {
            'tone_mismatch': not result.get('tone_match', True),
            'confidence': result.get('confidence', 0.5),
            'reason': result.get('reason', ''),
        }
    except:
        return {'tone_mismatch': False, 'confidence': 0.5, 'reason': 'LLM不可用'}


# ==================== 3. 附件/链接深度风险扫描 ====================

DANGEROUS_EXTENSIONS = {'.exe', '.bat', '.cmd', '.com', '.scr', '.vbs', '.ps1',
                        '.msi', '.reg', '.dll', '.pif', '.app', '.sh', '.run',
                        '.cpl', '.jar', '.wsf', '.hta', '.cgi', '.pl', '.py',
                        '.js', '.vbe', '.jse', '.ws', '.wsh', '.psm1'}

SUSPICIOUS_EXTENSIONS = {'.zip', '.rar', '.7z', '.iso', '.img', '.gz', '.tar',
                         '.docm', '.xlsm', '.pptm', '.pdf', '.html', '.htm'}

VIRUS_KEYWORDS = ['virus', 'malware', 'trojan', 'ransomware', 'spyware']


def scan_urls(text):
    """扫描邮件中的链接"""
    urls = re.findall(r'https?://[^\s<>"\'\)]+', text)
    if not urls:
        return {'urls': [], 'risk_score': 0.0, 'warnings': []}

    result = {'urls': [], 'risk_score': 0.0, 'warnings': []}
    high_risk_count = 0

    for url in urls:
        url_info = {'url': url, 'risk': 'low', 'reason': ''}

        # 短链接检测
        if re.search(r'(bit\.ly|t\.co|tinyurl|ow\.ly|is\.gd|buff\.ly|short\.link)', url):
            url_info['risk'] = 'high'
            url_info['reason'] = '短链接，无法预判真实目标'
            high_risk_count += 1

        # IP 地址链接
        elif re.search(r'https?://\d+\.\d+\.\d+\.\d+', url):
            url_info['risk'] = 'high'
            url_info['reason'] = 'IP直连，可疑'
            high_risk_count += 1

        # 可疑域名特征
        elif re.search(r'(login|verify|secure|account|update|confirm|auth|signin)', url, re.IGNORECASE):
            url_info['risk'] = 'medium'
            url_info['reason'] = '包含登录/验证关键词'

        # 非标准端口
        elif re.search(r':(?!80|443)\d{2,5}', url):
            url_info['risk'] = 'medium'
            url_info['reason'] = '非标准端口'

        result['urls'].append(url_info)

    if high_risk_count > 0:
        result['risk_score'] = min(1.0, high_risk_count * 0.4)
        result['warnings'].append(f'检测到 {high_risk_count} 个高风险链接')

    # 用 LLM 评估链接意图
    if len(urls) >= 2:
        try:
            prompt = f"""评估以下邮件链接的意图风险:
邮件内容: {text[:500]}
链接列表: {', '.join(urls[:5])}
返回JSON: {{"intent": "钓鱼/推广/正常/可疑", "risk_score": 0.0-1.0, "分析": "简短分析"}}"""
            response = _call_deepseek_api([
                {'role': 'user', 'content': prompt}
            ], temperature=0.1, max_tokens=150)
            llm_result = json.loads(_extract_json(response))
            result['llm_intent'] = llm_result
            result['risk_score'] = max(result['risk_score'], float(llm_result.get('risk_score', 0)))
        except:
            pass

    return result


def scan_attachment(filename, file_ext):
    """扫描附件风险"""
    ext = (file_ext or '').lower()
    if not ext.startswith('.'):
        ext = '.' + ext

    result = {'filename': filename, 'extension': ext, 'risk': 'low', 'can_download': True, 'warnings': []}

    # 高危可执行文件
    if ext in DANGEROUS_EXTENSIONS:
        result['risk'] = 'critical'
        result['can_download'] = False
        result['warnings'].append(f'高危可执行文件 ({ext})，已禁止下载')
        return result

    # 可疑文件
    if ext in SUSPICIOUS_EXTENSIONS:
        result['risk'] = 'high'
        result['warnings'].append(f'压缩/脚本文件 ({ext})，需谨慎处理')
        # 仍允许下载但风险标记

    # 文件名检测
    fname_lower = (filename or '').lower()
    if any(kw in fname_lower for kw in VIRUS_KEYWORDS):
        result['risk'] = 'critical'
        result['can_download'] = False
        result['warnings'].append('文件名包含病毒关键词')

    # 双扩展名检测
    if fname_lower.count('.') >= 2:
        parts = fname_lower.split('.')
        last_two = '.'.join(parts[-2:])
        if any(d in last_two for d in ['.doc.exe', '.pdf.exe', '.txt.exe', '.jpg.scr', '.png.bat']):
            result['risk'] = 'critical'
            result['can_download'] = False
            result['warnings'].append('双扩展名，伪装文件类型')

    return result


# ==================== 4. 用户个性化检测模型 ====================

def learn_user_preferences(user_id):
    """基于用户的手动标记行为，学习个性化偏好"""
    from database import get_db

    conn = get_db()
    cursor = conn.cursor()

    # 用户标记为垃圾的邮件关键词
    cursor.execute('''
        SELECT e.subject, e.content
        FROM emails e
        JOIN spam_log sl ON sl.email_id = e.id
        WHERE e.receiver_id = ? AND e.is_spam = 1
        ORDER BY sl.blocked_at DESC LIMIT 20
    ''', (user_id,))
    spam_marked = [dict(row) for row in cursor.fetchall()]

    # 用户从垃圾箱恢复的邮件（认为是正常邮件）
    cursor.execute('''
        SELECT subject, content FROM emails
        WHERE receiver_id = ? AND is_spam = 0 AND spam_score > 0
        ORDER BY created_at DESC LIMIT 20
    ''', (user_id,))
    restored = [dict(row) for row in cursor.fetchall()]

    conn.close()

    if not spam_marked and not restored:
        return {'has_profile': False, 'adjustment': 0.0, 'whitelist_keywords': [], 'note': '暂无足够的用户行为数据'}

    # 提取用户标记的垃圾关键词
    spam_kw = _extract_keywords(spam_marked)
    restore_kw = _extract_keywords(restored)

    # 用户特定白名单：常收但标记为正常的行业词汇
    whitelist = [kw for kw in restore_kw if kw not in spam_kw]

    # 计算个性化调整系数
    adjustment = min(0.15, len(spam_marked) * 0.005 + len(restored) * 0.003)

    return {
        'has_profile': True,
        'adjustment': round(adjustment, 4),
        'whitelist_keywords': whitelist[:10],
        'spam_samples': len(spam_marked),
        'restore_samples': len(restored),
        'note': f'基于 {len(spam_marked)} 条标记和 {len(restored)} 条恢复行为训练',
    }


def apply_personalized_adjustment(is_spam, score, user_profile, text):
    """应用用户个性化调整"""
    if not user_profile or not user_profile.get('has_profile'):
        return is_spam, score

    whitelist = user_profile.get('whitelist_keywords', [])
    adjustment = user_profile.get('adjustment', 0.0)

    # 如果邮件内容匹配用户白名单关键词，降低评分
    text_lower = text.lower()
    matched = sum(1 for kw in whitelist if kw.lower() in text_lower)
    if matched >= 2:
        adjusted_score = max(0.0, score - adjustment * matched)
        is_spam = adjusted_score >= 0.45
        return is_spam, round(adjusted_score, 4)

    return is_spam, score


def _extract_keywords(emails):
    """从邮件列表中提取高频关键词"""
    from collections import Counter
    words = Counter()
    for e in emails:
        text = f"{e.get('subject', '')} {e.get('content', '')}"
        # 简单分词
        for w in re.findall(r'[\u4e00-\u9fff]{2,}|\w{3,}', text):
            if len(w) >= 2:
                words[w.lower()] += 1
    return [w for w, c in words.most_common(20) if c >= 2]


def _extract_json(text):
    match = re.search(r'\{[\s\S]*\}', text)
    return match.group() if match else '{}'
