import sqlite3
import bcrypt
from config import DATABASE_PATH


def get_db():
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            face_encoding TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS emails (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sender_id INTEGER NOT NULL,
            receiver_id INTEGER NOT NULL,
            subject TEXT NOT NULL,
            content TEXT NOT NULL,
            is_spam INTEGER DEFAULT 0,
            spam_score REAL DEFAULT 0.0,
            is_deleted INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (sender_id) REFERENCES users(id),
            FOREIGN KEY (receiver_id) REFERENCES users(id)
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS spam_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email_id INTEGER NOT NULL,
            reason TEXT,
            blocked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (email_id) REFERENCES emails(id)
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS spam_warnings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            warning_type TEXT NOT NULL,
            message TEXT NOT NULL,
            is_read INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')

    conn.commit()
    conn.close()


# ---- User Operations ----

def create_user(username, password):
    conn = get_db()
    try:
        password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        cursor = conn.cursor()
        cursor.execute(
            'INSERT INTO users (username, password_hash) VALUES (?, ?)',
            (username, password_hash.decode('utf-8'))
        )
        conn.commit()
        user_id = cursor.lastrowid
        return user_id
    except sqlite3.IntegrityError:
        return None
    finally:
        conn.close()


def verify_user(username, password):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
    user = cursor.fetchone()
    conn.close()
    if user and bcrypt.checkpw(password.encode('utf-8'), user['password_hash'].encode('utf-8')):
        return dict(user)
    return None


def get_user_by_id(user_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT id, username, created_at FROM users WHERE id = ?', (user_id,))
    user = cursor.fetchone()
    conn.close()
    return dict(user) if user else None


def save_face_encoding(user_id, encoding_str):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('UPDATE users SET face_encoding = ? WHERE id = ?', (encoding_str, user_id))
    conn.commit()
    conn.close()


def get_face_encoding(username):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT id, face_encoding FROM users WHERE username = ? AND face_encoding IS NOT NULL', (username,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None


def get_all_users():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT id, username FROM users')
    users = cursor.fetchall()
    conn.close()
    return [dict(u) for u in users]


# ---- Email Operations ----

def save_email(sender_id, receiver_id, subject, content, is_spam=0, spam_score=0.0):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute(
        'INSERT INTO emails (sender_id, receiver_id, subject, content, is_spam, spam_score) VALUES (?, ?, ?, ?, ?, ?)',
        (sender_id, receiver_id, subject, content, is_spam, spam_score)
    )
    conn.commit()
    email_id = cursor.lastrowid
    conn.close()
    return email_id


def get_inbox(user_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT e.*, u.username as sender_name
        FROM emails e JOIN users u ON e.sender_id = u.id
        WHERE e.receiver_id = ? AND e.is_spam = 0 AND e.is_deleted = 0
        ORDER BY e.created_at DESC
    ''', (user_id,))
    emails = cursor.fetchall()
    conn.close()
    return [dict(e) for e in emails]


def get_sent_emails(user_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT e.*, u.username as receiver_name
        FROM emails e JOIN users u ON e.receiver_id = u.id
        WHERE e.sender_id = ? AND e.is_deleted = 0
        ORDER BY e.created_at DESC
    ''', (user_id,))
    emails = cursor.fetchall()
    conn.close()
    return [dict(e) for e in emails]


def get_spam_emails(user_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT e.*, u.username as sender_name
        FROM emails e JOIN users u ON e.sender_id = u.id
        WHERE e.receiver_id = ? AND e.is_spam = 1 AND e.is_deleted = 0
        ORDER BY e.created_at DESC
    ''', (user_id,))
    emails = cursor.fetchall()
    conn.close()
    return [dict(e) for e in emails]


def mark_as_spam(email_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('UPDATE emails SET is_spam = 1 WHERE id = ?', (email_id,))
    cursor.execute('INSERT INTO spam_log (email_id, reason) VALUES (?, ?)', (email_id, '系统自动识别为垃圾邮件'))
    conn.commit()
    conn.close()


def restore_from_spam(email_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('UPDATE emails SET is_spam = 0, spam_score = 0 WHERE id = ?', (email_id,))
    conn.commit()
    conn.close()


def delete_email(email_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('UPDATE emails SET is_deleted = 1 WHERE id = ?', (email_id,))
    conn.commit()
    conn.close()


def get_email_by_id(email_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT e.*, u1.username as sender_name, u2.username as receiver_name
        FROM emails e
        JOIN users u1 ON e.sender_id = u1.id
        JOIN users u2 ON e.receiver_id = u2.id
        WHERE e.id = ?
    ''', (email_id,))
    email = cursor.fetchone()
    conn.close()
    return dict(email) if email else None


# ---- Warning Operations ----

def create_warning(user_id, warning_type, message):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute(
        'INSERT INTO spam_warnings (user_id, warning_type, message) VALUES (?, ?, ?)',
        (user_id, warning_type, message)
    )
    conn.commit()
    conn.close()


def get_warnings(user_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute(
        'SELECT * FROM spam_warnings WHERE user_id = ? ORDER BY created_at DESC',
        (user_id,)
    )
    warnings = cursor.fetchall()
    conn.close()
    return [dict(w) for w in warnings]


def mark_warning_read(warning_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('UPDATE spam_warnings SET is_read = 1 WHERE id = ?', (warning_id,))
    conn.commit()
    conn.close()


def get_spam_stats(user_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute(
        'SELECT COUNT(*) as count FROM emails WHERE receiver_id = ? AND is_spam = 1 AND is_deleted = 0',
        (user_id,)
    )
    spam_count = cursor.fetchone()['count']
    cursor.execute(
        'SELECT COUNT(*) as count FROM emails WHERE receiver_id = ? AND is_spam = 0 AND is_deleted = 0',
        (user_id,)
    )
    normal_count = cursor.fetchone()['count']
    cursor.execute(
        'SELECT COUNT(*) as count FROM spam_warnings WHERE user_id = ? AND is_read = 0',
        (user_id,)
    )
    unread_warnings = cursor.fetchone()['count']
    conn.close()
    return {
        'spam_count': spam_count,
        'normal_count': normal_count,
        'unread_warnings': unread_warnings
    }
