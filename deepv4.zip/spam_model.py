import os
import re
import joblib
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from config import SPAM_MODEL_PATH, VECTORIZER_PATH

# 垃圾邮件常见关键词特征
SPAM_KEYWORDS = [
    '免费', '中奖', '优惠', '点击', '赚钱', '发财', '暴富', '代理', '加盟',
    '抽奖', '奖金', '现金', '大奖', '恭喜', '领取', '限时', '抢购', '秒杀',
    '最低价', '打折', '促销', '优惠券', '红包', '返利', '提现', '贷款',
    '信用卡', '理财', '投资', '股票', '涨停', '内幕', 'VIP', '会员',
    '激活', '验证', '密码', '账号', '登录', '异常', '安全', '风险',
    '赌博', '彩票', '六合彩', '时时彩', '百家乐', '澳门', '赌场',
    '色情', '成人', '美女', '裸聊', '视频', '约会', '一夜情',
    '发票', '代开', '办证', '文凭', '学历', '走私', '枪支',
    ' urgently', 'congratulations', 'winner', 'prize', 'click here',
    'free', 'offer', 'buy now', 'discount', 'limited time',
    'make money', 'work from home', 'get paid', 'earn',
    'guaranteed', 'risk free', 'credit card', 'loan',
    'viagra', 'casino', 'pharmacy', 'million',
]

SPAM_PATTERNS = [
    r'(?i)click\s*here',
    r'(?i)buy\s*now',
    r'(?i)limited\s*time\s*offer',
    r'(?i)act\s*now',
    r'(?i)100%\s*(free|satisfaction)',
    r'(?i)unsubscribe',
    r'(?i)\d+%\s*off',
    r'(?i)earn\s*\$\s*\d+',
    r'(?i)make\s*money',
    r'(?i)viagra|cialis',
    r'(?i)casino|gambling',
    r'(?i)\b(urgent|important)\b.*\b(respond|reply|action)\b',
    r'(?i)million.*dollar',
    r'(?i)credit\s*card',
    r'(?i)free\s*(trial|sample|access|quote|consultation)',
    r'(?i)work\s*from\s*home',
    r'(?i)multi.*level.*marketing',
    r'(?i)once\s*in\s*a\s*lifetime',
    r'[!]{3,}',
    r'[$]\s*\d+[,\d]*\.?\d*\s*(million|billion)?',
]


class SpamDetector:
    def __init__(self):
        self.model = None
        self.vectorizer = None
        self.load_model()

    def _train_on_data(self):
        """使用内置数据集训练模型"""
        # 正常邮件样本
        normal_emails = [
            '明天下午3点会议室开会，请大家准时参加',
            '附件是本月的财务报表，请查收',
            '小王，项目进展如何？需要我这边提供什么支持吗',
            '周末一起吃饭吧，好久没聚了',
            '这是修改后的合同，麻烦你看一下有没有问题',
            '张老师，请问下周的课程安排有变化吗',
            '妈妈，我下周回家，给你带了些特产',
            '请各位同事确认一下下周五的年会是否参加',
            '文件已经上传到共享文件夹了，大家可以下载',
            '明天有客户来访，请大家注意着装',
            '这是最新的产品设计稿，请各位提意见',
            '兄弟，你那个bug修好了吗？我这边测试通过了',
            '这个方案我觉得还需要再讨论一下',
            '本周五的团建活动改到下周了',
            '你的体检报告出来了，各项指标都正常，恭喜！',
            '刚看到你的邮件，我明天回复你详细方案',
            '关于上次讨论的技术方案，我整理了一份文档',
            '李总让我转告你，下周的出差取消了',
            '生日快乐！祝你新的一岁万事如意',
            '会议纪要如下：1. 确定了新版本发布时间...',
            '这是你需要的参考资料，我整理好了发给你',
            '收到，我这就安排人去处理',
            '毕业论文初稿写好了，麻烦导师帮忙看看',
            '明天下午有空吗？想跟你聊聊新项目的事',
            '快递已经发出，预计后天到达，请注意查收',
        ]

        # 垃圾邮件样本
        spam_emails = [
            '恭喜！您中了100万大奖！点击链接领取奖金 http://fake-prize.com',
            '快速赚钱方法，在家工作月入10万不是梦！',
            '限时优惠！全场5折起，错过今天等一年！',
            '【紧急通知】您的银行账户出现异常，请立即登录验证：http://phish-bank.com',
            '免费领取iPhone 15！数量有限，先到先得！点击了解详情',
            '代办各类证件，学历文凭，真实可查，价格优惠',
            '澳门赌场在线投注，百家乐、21点，注册送888元',
            '性感美女视频聊天，免费注册，24小时在线',
            '内部股票推荐，明天必涨停，免费跟单赚钱',
            '您有一个未领取的快递，请点击链接确认：http://fake-express.com',
            '招聘兼职刷单员，日结300-500元，手机即可操作',
            '信用卡套现，手续费低至1%，秒到账',
            '最新贷款产品，无需抵押，当天放款，利息低至0.5%',
            '恭喜您成为幸运用户！点击领取价值5000元大礼包',
            '您的QQ账号已被抽中为幸运之星，请回复消息领取奖励',
            '成人用品商城，保密发货，全场包邮',
            '最新六合彩特码，准确率99%，不中包赔',
            '免费领取VIP会员，激活账号即可享受所有特权',
            '代开发票，真实有效，量大从优',
            '彩票中奖秘籍，跟着买稳赚不赔',
        ]

        all_emails = normal_emails + spam_emails
        labels = [0] * len(normal_emails) + [1] * len(spam_emails)

        self.vectorizer = TfidfVectorizer(
            max_features=5000,
            ngram_range=(1, 2),
            token_pattern=r'(?u)\b\w+\b',
        )
        self.model = MultinomialNB(alpha=0.1)

        X = self.vectorizer.fit_transform(all_emails)
        self.model.fit(X, labels)

    def _extract_features(self, text):
        """提取文本特征"""
        features = {}

        # 关键词匹配数
        keyword_count = sum(1 for kw in SPAM_KEYWORDS if kw.lower() in text.lower())
        features['keyword_count'] = keyword_count

        # 垃圾邮件模式匹配
        pattern_matches = sum(1 for p in SPAM_PATTERNS if re.search(p, text))
        features['pattern_matches'] = pattern_matches

        # URL 数量
        features['url_count'] = len(re.findall(r'https?://\S+', text))

        # 感叹号数量
        features['exclamation_count'] = text.count('!')

        # 全大写单词比例
        words = text.split()
        if words:
            features['caps_ratio'] = sum(1 for w in words if w.isupper() and len(w) > 1) / len(words)
        else:
            features['caps_ratio'] = 0

        # 特殊字符数量
        features['special_char_count'] = len(re.findall(r'[$￥€£%#@&*]', text))

        # 文本长度
        features['text_length'] = len(text)

        return features

    def _rule_based_score(self, features, text):
        """基于规则的评分"""
        score = 0.0
        reasons = []

        if features['keyword_count'] >= 5:
            score += 0.4
            reasons.append(f'包含{features["keyword_count"]}个垃圾邮件关键词')
        elif features['keyword_count'] >= 3:
            score += 0.25
            reasons.append(f'包含{features["keyword_count"]}个可疑关键词')

        if features['pattern_matches'] >= 3:
            score += 0.3
            reasons.append(f'匹配{features["pattern_matches"]}个垃圾邮件模式')
        elif features['pattern_matches'] >= 1:
            score += 0.15
            reasons.append('匹配垃圾邮件特征模式')

        if features['url_count'] >= 3:
            score += 0.2
            reasons.append(f'包含{features["url_count"]}个链接')
        elif features['url_count'] >= 1:
            score += 0.1

        if features['exclamation_count'] >= 5:
            score += 0.1
            reasons.append('过多感叹号')

        if features['caps_ratio'] > 0.5:
            score += 0.1
            reasons.append('大写字母比例过高')

        if features['special_char_count'] >= 5:
            score += 0.1
            reasons.append('过多特殊字符')

        return min(score, 1.0), reasons

    def load_model(self):
        """加载已训练的模型"""
        if os.path.exists(SPAM_MODEL_PATH) and os.path.exists(VECTORIZER_PATH):
            self.model = joblib.load(SPAM_MODEL_PATH)
            self.vectorizer = joblib.load(VECTORIZER_PATH)
        else:
            self._train_on_data()

    def save_model(self):
        """保存模型"""
        if self.model and self.vectorizer:
            os.makedirs(os.path.dirname(SPAM_MODEL_PATH), exist_ok=True)
            joblib.dump(self.model, SPAM_MODEL_PATH)
            joblib.dump(self.vectorizer, VECTORIZER_PATH)

    def predict(self, text, subject=''):
        """预测邮件是否是垃圾邮件，返回 (is_spam, score, reasons, llm_result)

        llm_result: DeepSeek LLM 分析结果（如果启用了 LLM），否则为 None
        """
        if not text:
            return False, 0.0, ['空邮件内容'], None

        # 规则评分
        features = self._extract_features(text)
        rule_score, reasons = self._rule_based_score(features, text)

        # ML 模型评分
        ml_score = 0.0
        if self.model and self.vectorizer:
            try:
                X = self.vectorizer.transform([text])
                proba = self.model.predict_proba(X)[0]
                if len(proba) > 1:
                    ml_score = float(proba[1])
            except Exception:
                pass

        # LLM 智能分析
        llm_result = None
        llm_score = None
        from config import ENABLE_LLM
        if ENABLE_LLM:
            try:
                from deepseek_client import analyze_spam_with_llm
                llm_result = analyze_spam_with_llm(subject or '', text)
                if llm_result.get('is_spam') is not None:
                    llm_score = llm_result['score']
            except Exception as e:
                llm_result = {
                    'is_spam': None,
                    'score': 0.0,
                    'category': 'LLM不可用',
                    'reasoning': str(e),
                    'risk_level': 'unknown',
                    'suggestions': '',
                    'error': str(e),
                }

        # 综合评分
        if llm_score is not None:
            # LLM + ML + 规则，LLM权重更高
            combined_score = llm_score * 0.5 + ml_score * 0.3 + rule_score * 0.2
        else:
            combined_score = ml_score * 0.6 + rule_score * 0.4

        is_spam = combined_score >= 0.45

        if combined_score >= 0.7:
            reasons.insert(0, '高置信度垃圾邮件')
        elif combined_score >= 0.45:
            reasons.insert(0, '疑似垃圾邮件')

        return is_spam, round(combined_score, 4), reasons, llm_result


spam_detector = SpamDetector()
