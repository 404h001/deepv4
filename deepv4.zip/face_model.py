"""人脸识别模块 - 基于 OpenCV 实现"""
import os
import json
import base64
import numpy as np
from io import BytesIO
from PIL import Image
from config import FACE_DIR

try:
    import cv2
    FACE_REC_AVAILABLE = True
except ImportError:
    FACE_REC_AVAILABLE = False


def _base64_to_image(base64_str):
    """base64 → numpy 图像数组"""
    if ',' in base64_str:
        base64_str = base64_str.split(',')[1]
    image_data = base64.b64decode(base64_str)
    image = Image.open(BytesIO(image_data)).convert('RGB')
    return np.array(image)


def _base64_to_bytes(base64_str):
    """base64 → 字节数组，写入磁盘"""
    if ',' in base64_str:
        base64_str = base64_str.split(',')[1]
    return base64.b64decode(base64_str)


def _compute_hash(img):
    """计算感知哈希 (pHash)，用于人脸相似度比对"""
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    resized = cv2.resize(gray, (32, 32))
    dct = cv2.dct(np.float32(resized))
    dct_low = dct[:8, :8]
    avg = dct_low.mean()
    hash_bits = (dct_low > avg).flatten()
    return ''.join(['1' if b else '0' for b in hash_bits])


def _hash_similarity(h1, h2):
    """两个哈希值的相似度"""
    if len(h1) != len(h2):
        return 0.0
    diff = sum(c1 != c2 for c1, c2 in zip(h1, h2))
    return 1.0 - diff / len(h1)


def _extract_face_region(img):
    """使用 OpenCV Haar Cascade 检测并提取人脸区域"""
    cascade_path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
    face_cascade = cv2.CascadeClassifier(cascade_path)
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)

    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(80, 80))

    if len(faces) == 0:
        return None, None

    # 取最大人脸
    faces = sorted(faces, key=lambda f: f[2] * f[3], reverse=True)
    x, y, w, h = faces[0]
    face_img = img[y:y+h, x:x+w]
    return face_img, (x, y, w, h)


def detect_face(base64_image):
    """检测人脸并返回 pHash 值，同时返回人脸区域"""
    if not FACE_REC_AVAILABLE:
        raise RuntimeError('OpenCV 未安装，请运行: pip install opencv-python')

    img = _base64_to_image(base64_image)
    face_img, bbox = _extract_face_region(img)

    if face_img is None:
        return None

    phash = _compute_hash(face_img)
    return {'phash': phash, 'bbox': bbox}


def register_face(user_id, base64_image):
    """注册人脸：保存原始图像 + 人脸 pHash"""
    if not FACE_REC_AVAILABLE:
        return False, 'OpenCV 未安装，请运行: pip install opencv-python'

    img = _base64_to_image(base64_image)
    face_img, bbox = _extract_face_region(img)

    if face_img is None:
        return False, '未检测到人脸，请确保光线充足且面部正对摄像头'

    # 计算并保存人脸特征
    phash = _compute_hash(face_img)
    encoding_str = json.dumps({'phash': phash, 'version': 'opencv-2.0'})

    from database import save_face_encoding
    save_face_encoding(user_id, encoding_str)

    # 保存原始图像
    user_dir = os.path.join(FACE_DIR, str(user_id))
    os.makedirs(user_dir, exist_ok=True)

    data = _base64_to_bytes(base64_image)
    with open(os.path.join(user_dir, 'face.jpg'), 'wb') as f:
        f.write(data)

    # 保存人脸裁剪图
    face_pil = Image.fromarray(face_img)
    face_pil.save(os.path.join(user_dir, 'face_crop.jpg'))

    return True, '人脸注册成功'


def verify_face(base64_image, username):
    """验证人脸登录"""
    if not FACE_REC_AVAILABLE:
        return False, 'OpenCV 未安装，无法使用人脸识别', None

    img = _base64_to_image(base64_image)
    face_img, bbox = _extract_face_region(img)

    if face_img is None:
        return False, '未检测到人脸，请正对摄像头', None

    new_phash = _compute_hash(face_img)

    from database import get_face_encoding
    user_data = get_face_encoding(username)
    if not user_data:
        return False, '该用户未注册人脸，请使用密码登录', None

    try:
        stored = json.loads(user_data['face_encoding'])
        stored_phash = stored['phash']
    except (json.JSONDecodeError, KeyError):
        return False, '人脸数据格式错误，请重新注册', None

    similarity = _hash_similarity(new_phash, stored_phash)

    # 阈值设为 0.7（OpenCV 方案需要更宽松的阈值）
    if similarity >= 0.7:
        return True, f'人脸验证成功 (相似度: {similarity:.1%})', user_data['id']
    else:
        return False, f'人脸不匹配 (相似度: {similarity:.1%}，需要 ≥70%)', None


def has_face_registered(username):
    """检查用户是否已注册人脸"""
    from database import get_face_encoding
    return get_face_encoding(username) is not None
