import os
import json
import base64
import numpy as np
from io import BytesIO
from PIL import Image
from config import FACE_DIR

try:
    import face_recognition
    FACE_REC_AVAILABLE = True
except ImportError:
    FACE_REC_AVAILABLE = False


def _base64_to_image(base64_str):
    """将base64字符串转为numpy图像数组"""
    if ',' in base64_str:
        base64_str = base64_str.split(',')[1]
    image_data = base64.b64decode(base64_str)
    image = Image.open(BytesIO(image_data))
    image = image.convert('RGB')
    return np.array(image)


def _encoding_to_str(encoding):
    """将face encoding转为字符串"""
    return json.dumps(encoding.tolist())


def _str_to_encoding(encoding_str):
    """将字符串转为face encoding numpy数组"""
    return np.array(json.loads(encoding_str))


def detect_face(base64_image):
    """从图像中检测人脸并返回encoding"""
    if not FACE_REC_AVAILABLE:
        raise RuntimeError('face_recognition库未安装，请运行: pip install face-recognition')

    img = _base64_to_image(base64_image)
    encodings = face_recognition.face_encodings(img)

    if len(encodings) == 0:
        return None
    return encodings[0]


def register_face(user_id, base64_image):
    """注册用户人脸"""
    encoding = detect_face(base64_image)
    if encoding is None:
        return False, '未检测到人脸，请确保光线充足且面部正对摄像头'

    encoding_str = _encoding_to_str(encoding)
    from database import save_face_encoding
    save_face_encoding(user_id, encoding_str)

    # 同时保存图片
    user_dir = os.path.join(FACE_DIR, str(user_id))
    os.makedirs(user_dir, exist_ok=True)
    img = _base64_to_image(base64_image)
    Image.fromarray(img).save(os.path.join(user_dir, 'face.jpg'))

    return True, '人脸注册成功'


def verify_face(base64_image, username):
    """验证人脸登录"""
    if not FACE_REC_AVAILABLE:
        return False, 'face_recognition库未安装', None

    encoding = detect_face(base64_image)
    if encoding is None:
        return False, '未检测到人脸', None

    from database import get_face_encoding
    user_data = get_face_encoding(username)
    if not user_data:
        return False, '该用户未注册人脸，请使用密码登录', None

    stored_encoding = _str_to_encoding(user_data['face_encoding'])

    # 使用默认容差0.6进行比对
    matches = face_recognition.compare_faces([stored_encoding], encoding, tolerance=0.5)
    distance = float(face_recognition.face_distance([stored_encoding], encoding)[0])

    if matches[0]:
        return True, '人脸验证成功', user_data['id']
    else:
        return False, f'人脸不匹配 (相似度: {1-distance:.2%})', None


def has_face_registered(username):
    """检查用户是否已注册人脸"""
    from database import get_face_encoding
    return get_face_encoding(username) is not None
