"""AI 增强助手：智能回复、情感分析、日程提取、邮件润色"""
import json
import re
from deepseek_client import _call_deepseek_api


# ==================== 1. AI 智能回复建议 ====================

def generate_reply_suggestions(subject, content, sender_name):
    """基于邮件内容生成 3 条回复草稿"""
    email_text = f'发件人: {sender_name}\n主题: {subject}\n内容: {content[:1200]}'

    prompt = f"""你是邮件写作助手。请为以下邮件生成3条不同风格的回复草稿（每条30-80字）：

{email_text}

请严格返回JSON:
{{
    "replies": [
        {{"style": "正式回复", "text": "..."}},
        {{"style": "简短回复", "text": "..."}},
        {{"style": "追问/确认", "text": "..."}}
    ],
    "context_hint": "对这封邮件的1句话理解"
}}"""

    try:
        resp = _call_deepseek_api([{'role': 'user', 'content': prompt}], temperature=0.5, max_tokens=500)
        result = json.loads(_extract_json(resp))
        return {'success': True, **result}
    except Exception as e:
        return {'success': False, 'error': str(e)[:80], 'replies': [], 'context_hint': ''}


# ==================== 2. 邮件情感与紧急度分析 ====================

def analyze_sentiment(subject, content):
    """分析邮件情感倾向和紧急程度"""
    email_text = f'主题: {subject}\n内容: {content[:1000]}'

    prompt = f"""分析以下邮件的情感和紧急度：

{email_text}

返回JSON:
{{
    "sentiment": "正面/中性/负面",
    "sentiment_score": -1.0到1.0（负面到正面）,
    "urgency": "紧急/重要/普通/低优先",
    "urgency_score": 0.0-1.0,
    "emotion_tags": ["情绪标签列表，如：焦虑/友好/命令式/感谢/催促"],
    "tone": "正式/友好/命令式/冷淡/热情",
    "key_intent": "邮件核心意图，10字以内"
}}"""

    try:
        resp = _call_deepseek_api([{'role': 'user', 'content': prompt}], temperature=0.1, max_tokens=300)
        result = json.loads(_extract_json(resp))
        return {'success': True, **result}
    except:
        return local_sentiment(subject, content)


def local_sentiment(subject, content):
    """本地情感分析（回退方案）"""
    text = f'{subject} {content}'
    positive = ['谢谢', '感谢', '好的', '没问题', '辛苦了', '恭喜', '赞', 'good', 'great', 'thanks']
    negative = ['紧急', '立刻', '马上', '必须', '严重', '问题', '故障', '投诉', '抱歉', 'urgent']
    urgent = ['紧急', 'ASAP', '马上', '立刻', '尽快', 'deadline', '截止', '延误']

    pos = sum(1 for w in positive if w in text)
    neg = sum(1 for w in negative if w in text)
    urg = sum(1 for w in urgent if w in text)

    score = min(1, max(-1, (pos - neg) * 0.3))
    return {
        'success': True,
        'sentiment': '正面' if score > 0.2 else '负面' if score < -0.2 else '中性',
        'sentiment_score': round(score, 2),
        'urgency': '紧急' if urg >= 2 else '重要' if urg >= 1 else '普通',
        'urgency_score': min(1.0, urg * 0.3),
        'emotion_tags': (['催促'] if urg > 0 else []) + (['感谢'] if pos > 0 else []),
        'tone': '正式',
        'key_intent': subject[:10] if subject else '未知',
    }


# ==================== 3. 智能日程/待办提取 ====================

def extract_todos(subject, content):
    """从邮件中提取日程和待办事项"""
    email_text = f'主题: {subject}\n内容: {content[:1500]}'

    prompt = f"""从以下邮件中提取所有日程、会议、待办事项和截止日期：

{email_text}

返回JSON:
{{
    "events": [
        {{"type": "会议/截止日/待办/提醒", "title": "事项标题", "time": "时间描述", "people": ["相关人"], "location": "地点或空字符串"}}
    ],
    "summary": "关键事项一句话总结"
}}

如果没有明确的日程安排，events为空数组。"""

    try:
        resp = _call_deepseek_api([{'role': 'user', 'content': prompt}], temperature=0.1, max_tokens=400)
        result = json.loads(_extract_json(resp))
        return {'success': True, **result}
    except:
        return {'success': True, 'events': [], 'summary': '暂未识别到明确日程'}


# ==================== 4. AI 邮件润色与模板 ====================

def polish_email(content, style='professional'):
    """润色邮件文本"""
    styles = {
        'professional': '正式专业',
        'friendly': '友好亲切',
        'concise': '简洁高效',
        'persuasive': '有说服力',
    }
    style_cn = styles.get(style, '正式专业')

    prompt = f"""请将以下邮件草稿润色为{style_cn}风格，保持原意不变，修正语法和措辞：

{content[:1500]}

返回JSON:
{{
    "polished": "润色后的文本",
    "changes": ["3个以内主要修改点"]
}}"""

    try:
        resp = _call_deepseek_api([{'role': 'user', 'content': prompt}], temperature=0.4, max_tokens=800)
        result = json.loads(_extract_json(resp))
        return {'success': True, **result}
    except Exception as e:
        return {'success': False, 'error': str(e)[:80], 'polished': content}


def generate_template(purpose):
    """根据意图生成邮件模板"""
    prompt = f"""请为以下场景生成一封邮件模板（50-150字）：

场景: {purpose}

返回JSON:
{{
    "subject": "邮件主题",
    "body": "邮件正文模板",
    "tips": ["2条写作建议"]
}}"""

    try:
        resp = _call_deepseek_api([{'role': 'user', 'content': prompt}], temperature=0.6, max_tokens=500)
        result = json.loads(_extract_json(resp))
        return {'success': True, **result}
    except Exception as e:
        return {'success': False, 'error': str(e)[:80]}


def _extract_json(text):
    match = re.search(r'\{[\s\S]*\}', text)
    return match.group() if match else '{}'
