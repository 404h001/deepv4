// 全局状态
const STATE = {
    currentUser: null,
    faceStream: null,
    faceStreamReg: null,
    capturedFace: null,
    capturedFaceReg: null,
};

const API = '/api';

// ==================== 工具函数 ====================
function $(id) { return document.getElementById(id); }
function toast(msg, type = 'info') {
    const t = document.createElement('div');
    t.className = `toast ${type}`;
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 3000);
}

async function api(method, url, body = null) {
    const opts = { method, headers: { 'Content-Type': 'application/json' } };
    if (body) opts.body = JSON.stringify(body);
    const resp = await fetch(API + url, opts);
    return resp.json();
}

function formatTime(ts) {
    if (!ts) return '';
    const d = new Date(ts);
    const now = new Date();
    const diff = now - d;
    if (diff < 60000) return '刚刚';
    if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前';
    if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前';
    return d.toLocaleDateString('zh-CN') + ' ' + d.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
}

// ==================== 导航 ====================
let _navHistory = [];  // 导航历史栈
let _currentPage = 'dashboard';

function showPage(name) {
    // 非仪表盘页面时记录历史
    if (_currentPage !== name && _currentPage !== 'dashboard') {
        _navHistory.push(_currentPage);
    }
    _currentPage = name;

    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.sidebar-nav a').forEach(a => a.classList.remove('active'));

    const page = $('page-' + name);
    if (page) page.classList.add('active');
    const link = document.querySelector(`[data-page="${name}"]`);
    if (link) link.classList.add('active');

    if (name === 'dashboard') { loadDashboard(); _navHistory = []; }
    if (name === 'inbox') loadInbox();
    if (name === 'sent') loadSent();
    if (name === 'spam') loadSpam();
    if (name === 'compose') loadComposeForm();
    if (name === 'warnings') loadWarnings();
    if (name === 'cleanup') loadCleanupPage();
    if (name === 'settings') loadSettings();
}

function goBack() {
    const prev = _navHistory.pop();
    if (prev) {
        _currentPage = prev;
        showPageSilent(prev);
    } else {
        showPage('dashboard');
    }
}

function showPageSilent(name) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.sidebar-nav a').forEach(a => a.classList.remove('active'));
    const page = $('page-' + name);
    if (page) page.classList.add('active');
    const link = document.querySelector(`[data-page="${name}"]`);
    if (link) link.classList.add('active');

    // 静默加载，不覆盖历史
    if (name === 'dashboard') {
        setTimeout(() => loadDashboard(), 10);
    } else if (name === 'inbox') {
        setTimeout(() => loadInbox(), 10);
    }
}

function showEmailDetail(emailId) {
    _navHistory.push(_currentPage);
    _currentPage = 'detail';
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.sidebar-nav a').forEach(a => a.classList.remove('active'));
    const page = $('page-detail');
    if (page) page.classList.add('active');
    loadEmailDetail(emailId);
}

// ==================== Auth ====================
function showRegister() {
    $('loginForm').style.display = 'none';
    $('registerForm').style.display = 'block';
}
function showLogin() {
    $('registerForm').style.display = 'none';
    $('loginForm').style.display = 'block';
}

async function handleRegister() {
    const username = $('regUsername').value.trim();
    const password = $('regPassword').value.trim();
    const password2 = $('regPassword2').value.trim();

    if (!username || !password) return toast('请填写用户名和密码', 'error');
    if (username.length < 3) return toast('用户名至少3个字符', 'error');
    if (password.length < 6) return toast('密码至少6个字符', 'error');
    if (password !== password2) return toast('两次密码不一致', 'error');

    const res = await api('POST', '/register', { username, password });
    if (res.success) {
        toast('注册成功！', 'success');
        // 如果已拍摄人脸，注册人脸
        if (STATE.capturedFaceReg && res.user_id) {
            const faceRes = await api('POST', '/face/register', {
                user_id: res.user_id,
                face_image: STATE.capturedFaceReg
            });
            if (faceRes.success) toast('人脸注册成功！', 'success');
            else toast(faceRes.message, 'error');
        }
        showLogin();
        $('regUsername').value = '';
        $('regPassword').value = '';
        $('regPassword2').value = '';
    } else {
        toast(res.message, 'error');
    }
}

async function handleLogin() {
    const username = $('loginUsername').value.trim();
    const password = $('loginPassword').value.trim();
    if (!username || !password) return toast('请输入用户名和密码', 'error');

    const res = await api('POST', '/login', { username, password });
    if (res.success) {
        STATE.currentUser = res.user;
        enterApp();
    } else {
        toast(res.message, 'error');
    }
}

// ==================== 人脸摄像头 ====================
async function startFaceCamera() {
    console.log('[CAM] startFaceCamera called');
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        console.log('[CAM] stream obtained:', stream.id);
        STATE.faceStream = stream;
        const video = $('faceVideo');
        video.srcObject = stream;
        video.style.display = 'block';
        $('btnFaceStart').style.display = 'none';
        $('btnFaceLogin').style.display = 'block';
        $('facePreview').style.display = 'none';
        alert('摄像头已开启，请正对镜头后点击「人脸识别登录」');
    } catch (e) {
        console.error('[CAM] error:', e.name, e.message);
        alert('摄像头错误: ' + (e.message || e.name || '未知') + '\n\n请确保:\n1. 浏览器已授权摄像头权限\n2. 摄像头未被其他程序占用\n3. 设备已连接摄像头');
    }
}

async function startFaceCameraReg() {
    console.log('[CAM] startFaceCameraReg called');
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        console.log('[CAM] stream obtained:', stream.id);
        STATE.faceStreamReg = stream;
        const video = $('faceVideoReg');
        video.srcObject = stream;
        video.style.display = 'block';
        $('btnFaceStartReg').style.display = 'none';
        $('btnFaceCaptureReg').style.display = 'block';
        alert('摄像头已开启，调整好角度后点击「拍照注册」');
    } catch (e) {
        console.error('[CAM] error:', e.name, e.message);
        alert('摄像头错误: ' + (e.message || e.name || '未知') + '\n\n请确保:\n1. 浏览器已授权摄像头权限\n2. 摄像头未被其他程序占用\n3. 设备已连接摄像头');
    }
}

async function handleFaceLogin() {
    const username = $('loginUsername').value.trim();
    if (!username) return toast('请先输入用户名', 'error');

    const video = $('faceVideo');
    const canvas = $('faceCanvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0);

    const imageData = canvas.toDataURL('image/jpeg');
    $('facePreview').src = imageData;
    $('facePreview').style.display = 'block';

    const res = await api('POST', '/login/face', { username, face_image: imageData });
    if (res.success) {
        STATE.currentUser = res.user;
        stopCamera(STATE.faceStream);
        enterApp();
    } else {
        toast(res.message, 'error');
    }
}

function captureFaceReg() {
    const video = $('faceVideoReg');
    const canvas = $('faceCanvasReg');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0);
    STATE.capturedFaceReg = canvas.toDataURL('image/jpeg');
    $('facePreviewReg').src = STATE.capturedFaceReg;
    $('facePreviewReg').style.display = 'block';
    toast('人脸已捕捉', 'success');
    stopCamera(STATE.faceStreamReg);
}

function stopCamera(stream) {
    if (stream) {
        stream.getTracks().forEach(t => t.stop());
    }
}

// ==================== 进入应用 ====================
function enterApp() {
    $('authPage').style.display = 'none';
    $('appPage').classList.add('active');
    $('sidebarUsername').textContent = STATE.currentUser.username;
    loadDashboard();
    loadBadges();
}

function handleLogout() {
    STATE.currentUser = null;
    $('appPage').classList.remove('active');
    $('authPage').style.display = 'flex';
    showLogin();
    $('loginUsername').value = '';
    $('loginPassword').value = '';
}

// ==================== 统计数据 ====================
async function loadBadges() {
    const stats = await api('GET', `/stats/${STATE.currentUser.id}`);
    if (stats.success) {
        $('spamBadge').textContent = stats.stats.spam_count || '0';
        $('warnBadge').textContent = stats.stats.unread_warnings || '0';
    }
}

// ==================== 仪表盘 ====================
async function loadDashboard() {
    if (!STATE.currentUser) return;
    const stats = await api('GET', `/stats/${STATE.currentUser.id}`);
    if (stats.success) {
        const s = stats.stats;
        $('dashboardStats').innerHTML = `
            <div class="stat-card primary" onclick="showPage('inbox')" style="cursor:pointer;" title="点击查看收件箱详情">
                <div class="stat-icon">&#x1f4e8;</div>
                <div class="stat-value">${s.normal_count}</div>
                <div class="stat-label">Normal Emails · 正常邮件</div>
                <div style="font-size:.68rem;color:var(--accent-light);margin-top:6px;">点击查看详情 &#x2192;</div>
            </div>
            <div class="stat-card danger" onclick="showPage('spam')" style="cursor:pointer;" title="点击查看拦截详情">
                <div class="stat-icon">&#x1f6ab;</div>
                <div class="stat-value">${s.spam_count}</div>
                <div class="stat-label">Blocked Spam · 已拦截</div>
                <div style="font-size:.68rem;color:var(--danger);margin-top:6px;">点击查看详情 &#x2192;</div>
            </div>
            <div class="stat-card warning" onclick="showPage('warnings')" style="cursor:pointer;" title="点击查看预警详情">
                <div class="stat-icon">&#x26a0;&#xfe0f;</div>
                <div class="stat-value">${s.unread_warnings}</div>
                <div class="stat-label">Alerts · 未读预警</div>
                <div style="font-size:.68rem;color:var(--warning);margin-top:6px;">点击查看详情 &#x2192;</div>
            </div>
            <div class="stat-card success" onclick="showPage('cleanup')" style="cursor:pointer;" title="点击进入清理助手">
                <div class="stat-icon">&#x1f9e0;</div>
                <div class="stat-value">AI</div>
                <div class="stat-label">DeepSeek V4 · 在线防护</div>
                <div style="font-size:.68rem;color:var(--success);margin-top:6px;">点击管理助手 &#x2192;</div>
            </div>
        `;
        $('spamBadge').textContent = s.spam_count || '0';
        $('warnBadge').textContent = s.unread_warnings || '0';
    }

    // 加载收件箱摘要
    const inbox = await api('GET', `/emails/inbox/${STATE.currentUser.id}`);
    if (inbox.success) {
        const list = inbox.emails.slice(0, 5);
        if (list.length === 0) {
            $('recentEmails').innerHTML = '<div class="empty"><div class="icon">📭</div><p>暂无邮件</p></div>';
        } else {
            $('recentEmails').innerHTML = list.map(e => renderEmailItem(e, 'inbox')).join('');
        }
    }

    // 加载 AI 智能解读
    loadDashboardInsights();
}

// ==================== AI 仪表盘智能解读 ====================

async function loadDashboardInsights() {
    try {
        const res = await api('GET', `/ai/dashboard-insights/${STATE.currentUser.id}`);
        if (!res.success) return;

        // AI 智能解读
        const insightDiv = $('dashboardInsight');
        if (insightDiv && res.insight) {
            insightDiv.style.display = 'block';
            $('insightText').textContent = res.insight;
        }

        // AI 邮件分组
        if (res.groups && res.groups.length > 0) {
            const colorMap = {
                '工作通知': 'work', '个人邮件': 'personal', '订阅推广': 'subscription',
                '验证码': 'auth', '物流通知': 'logistics', '账单财务': 'finance',
                '社交互动': 'social', '系统通知': 'auth', '其他': 'other',
            };
            $('emailGroups').innerHTML = res.groups.map(g => {
                const catClass = colorMap[g.name] || 'other';
                const icons = { '工作通知':'💼','个人邮件':'💬','订阅推广':'📢','验证码':'🔑','物流通知':'📦','账单财务':'💰','社交互动':'👥','系统通知':'⚙️' };
                return `
                    <div class="stat-card" style="cursor:pointer;text-align:center;" onclick="showPage('inbox')" title="${g.name}: ${g.count}封">
                        <div style="font-size:1.5rem;margin-bottom:4px;">${icons[g.name]||'📧'}</div>
                        <div style="font-size:1.3rem;font-weight:800;color:var(--accent-light);">${g.count}</div>
                        <div style="font-size:.72rem;color:var(--text-muted);">${g.name}</div>
                        <div style="font-size:.65rem;color:var(--text-muted);margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${g.latest||''}</div>
                    </div>`;
            }).join('');
        }
    } catch (_) { }
}

// ==================== 收件箱 ====================
async function loadInbox() {
    if (!STATE.currentUser) return;
    const res = await api('GET', `/emails/inbox/${STATE.currentUser.id}`);
    if (res.success) {
        const list = res.emails;
        if (list.length === 0) {
            $('inboxList').innerHTML = '<div class="empty"><div class="icon">📭</div><p>收件箱为空</p></div>';
        } else {
            $('inboxList').innerHTML = list.map(e => renderEmailItem(e, 'inbox')).join('');
            classifyInboxEmails(list.slice(0, 8));
        }
    }
}

async function classifyInboxEmails(emails) {
    for (const e of emails) {
        try {
            const cls = await api('POST', '/emails/classify', { subject: e.subject, content: (e.content || '').substring(0, 200) });
            if (cls.success && cls.category) {
                e._category = cls.category;
            }
        } catch (_) { }
    }
    const res2 = await api('GET', `/emails/inbox/${STATE.currentUser.id}`);
    if (res2.success) {
        const list = res2.emails;
        for (const e of list) {
            const found = emails.find(x => x.id === e.id);
            if (found && found._category) e._category = found._category;
        }
        $('inboxList').innerHTML = list.map(e => renderEmailItem(e, 'inbox')).join('');
    }
}

async function loadSent() {
    if (!STATE.currentUser) return;
    const res = await api('GET', `/emails/sent/${STATE.currentUser.id}`);
    if (res.success) {
        const list = res.emails;
        if (list.length === 0) {
            $('sentList').innerHTML = '<div class="empty"><div class="icon">📤</div><p>暂无已发送邮件</p></div>';
        } else {
            $('sentList').innerHTML = list.map(e => renderEmailItem(e, 'sent')).join('');
        }
    }
}

async function loadSpam() {
    if (!STATE.currentUser) return;
    const res = await api('GET', `/emails/spam/${STATE.currentUser.id}`);
    if (res.success) {
        const list = res.emails;
        if (list.length === 0) {
            $('spamList').innerHTML = '<div class="empty"><div class="icon">🛡️</div><p>垃圾箱为空，系统正在保护您的邮箱</p></div>';
        } else {
            $('spamList').innerHTML = list.map(e => renderEmailItem(e, 'spam')).join('');
        }
    }
}

function renderEmailItem(e, type) {
    const spamBadge = e.is_spam ? '<span class="badge-spam">垃圾</span>' : '';
    const scoreHtml = e.spam_score > 0 ? `<span class="score">评分:${(e.spam_score * 100).toFixed(0)}%</span>` : '';

    let actions = '';
    if (type === 'inbox') {
        actions = `<button class="btn btn-warning btn-xs" onclick="event.stopPropagation();markSpam(${e.id})">标记垃圾</button>`;
    }
    if (type === 'spam') {
        actions = `<button class="btn btn-success btn-xs" onclick="event.stopPropagation();restoreEmail(${e.id})">恢复</button>`;
    }
    actions += `<button class="btn btn-danger btn-xs" onclick="event.stopPropagation();deleteEmailConfirm(${e.id})">删除</button>`;

    const senderDisplay = type === 'sent' ? `发给: ${e.receiver_name || ''}` : (e.sender_name || '');
    const preview = (e.content || '').substring(0, 80);
    const catClass = (e._category || '').toLowerCase().replace(/\s+/g, '-');
    const catTag = e._category ? `<span class="cat-tag ${mapCategoryClass(e._category)}">${e._category}</span>` : '';

    return `
        <div class="email-item" onclick="showEmailDetail(${e.id})" onmouseenter="showSummary(${e.id}, this)" onmouseleave="hideSummary()">
            <span class="sender">${senderDisplay}</span>
            <span class="subject">${spamBadge} ${catTag} ${e.subject}</span>
            <span class="preview">${preview}</span>
            ${scoreHtml}
            <span class="time">${formatTime(e.created_at)}</span>
            <span class="actions">${actions}</span>
        </div>
    `;
}

async function loadEmailDetail(emailId) {
    const res = await api('GET', `/emails/${emailId}`);
    if (res.success) {
        const e = res.email;
        const spamLabel = e.is_spam ? '<span class="badge-spam">垃圾邮件</span>' : '';
        $('emailDetail').innerHTML = `
            <div style="margin-bottom:14px;"><a class="back-btn" onclick="goBack()">&#x2190; 返回</a></div>
            <div class="detail-header">
                <h2>${spamLabel} ${e.subject}</h2>
                <div class="detail-meta">
                    <span>发件人: ${e.sender_name}</span>
                    <span>收件人: ${e.receiver_name}</span>
                    <span>时间: ${formatTime(e.created_at)}</span>
                    ${e.spam_score > 0 ? `<span>垃圾评分: ${(e.spam_score * 100).toFixed(0)}%</span>` : ''}
                </div>
            </div>
            <div style="margin-bottom:14px;display:flex;gap:8px;">
                <span class="translate-toggle" onclick="doTranslate('auto')" id="btnTransAuto">&#x1f310; AI 智能翻译</span>
                <span class="translate-toggle" onclick="doTranslate('en2zh')" id="btnTransEn">&#x1f1ec;&#x1f1e7; 英→中</span>
                <span class="translate-toggle" onclick="doTranslate('zh2en')" id="btnTransZh">&#x1f1e8;&#x1f1f3; 中→英</span>
            </div>
            <div class="detail-body" id="detailBody">${e.content || '(无内容)'}</div>
            <div id="transPanel"></div>
            <div class="detail-actions">
                ${e.is_spam
                    ? `<button class="btn btn-success btn-sm" onclick="restoreEmail(${e.id})">恢复为正常邮件</button>`
                    : `<button class="btn btn-warning btn-sm" onclick="markSpam(${e.id})">标记为垃圾邮件</button>`
                }
                <button class="btn btn-danger btn-sm" onclick="deleteEmailConfirm(${e.id})">删除</button>
                <button class="btn btn-outline btn-sm" onclick="showPage('inbox')">返回收件箱</button>
            </div>
            <div id="aiAssistantPanel"></div>
        `;
        // 异步加载 AI 助手面板
        setTimeout(() => loadAiAssistant(emailId, e.sender_name, e.subject, e.content), 100);
    }
}

// ==================== 邮件操作 ====================
async function markSpam(emailId) {
    const res = await api('POST', `/emails/${emailId}/mark-spam`);
    if (res.success) {
        toast('已标记为垃圾邮件', 'success');
        loadInbox();
        loadBadges();
    }
}

async function restoreEmail(emailId) {
    const res = await api('POST', `/emails/${emailId}/restore`);
    if (res.success) {
        toast('已恢复为正常邮件', 'success');
        loadSpam();
        loadBadges();
    }
}

async function deleteEmailConfirm(emailId) {
    if (confirm('确定要删除这封邮件吗？')) {
        const res = await api('POST', `/emails/${emailId}/delete`);
        if (res.success) {
            toast('邮件已删除', 'success');
            loadInbox();
            loadSpam();
            loadBadges();
            showPage('inbox');
        }
    }
}

// ==================== 写邮件 ====================
async function loadComposeForm() {
    const res = await api('GET', '/users');
    if (res.success) {
        const users = res.users.filter(u => u.id !== STATE.currentUser.id);
        $('composeReceiver').innerHTML = '<option value="">选择收件人...</option>' +
            users.map(u => `<option value="${u.id}">${u.username}</option>`).join('');
    }
    $('composeSubject').value = '';
    $('composeContent').value = '';
    $('contentCheckResult').innerHTML = '';

    // 同时加载模拟接收页面的收件人
    const extReceiver = $('extReceiver');
    if (extReceiver) {
        const res2 = await api('GET', '/users');
        if (res2.success) {
            extReceiver.innerHTML = '<option value="">选择收件人...</option>' +
                res2.users.map(u => `<option value="${u.id}">${u.username}</option>`).join('');
        }
    }
}

// 防抖定时器
let _checkTimer = null;

async function checkContentRealtime() {
    clearTimeout(_checkTimer);

    const text = $('composeContent').value.trim();
    if (text.length < 8) {
        $('contentCheckResult').innerHTML = '';
        return;
    }

    // 显示加载状态
    $('contentCheckResult').innerHTML = `
        <div class="check-result" style="background:rgba(108,92,231,.06);color:var(--accent-light);border:1px solid rgba(108,92,231,.15);">
            <span class="status-dot" style="background:var(--accent);box-shadow:0 0 8px var(--accent-glow);animation:pulse 1.2s ease infinite;display:inline-block;"></span>
            DeepSeek AI 正在分析中...
        </div>`;

    // 防抖 800ms 后再调用 API
    _checkTimer = setTimeout(async () => {
        try {
            const [res, deepRes] = await Promise.all([
                api('POST', '/check-content', { text }),
                runDeepScan(text),
            ]);

            if (!res) throw new Error('无响应');

            const llmInfo = buildLlmInfo(res.llm_analysis);
            const scorePercent = res.score ? (res.score * 100).toFixed(0) : '0';
            const reasonsStr = (res.reasons && res.reasons.length) ? res.reasons.join('; ') : '';

            let html = '';
            if (res.is_spam) {
                html += `
                    <div class="check-result danger">
                        <strong>&#x26a0;&#xfe0f; 警告：垃圾邮件</strong>（评分: ${scorePercent}%）
                        ${reasonsStr ? '<br>特征: ' + reasonsStr : ''}
                        ${llmInfo}
                    </div>`;
            } else {
                html += `
                    <div class="check-result success">
                        <strong>&#x2705; 内容安全</strong>（评分: ${scorePercent}%）
                        ${reasonsStr ? '<br>' + reasonsStr : ''}
                        ${llmInfo}
                    </div>`;
            }

            html += buildDeepPanel(deepRes);
            $('contentCheckResult').innerHTML = html;
        } catch (e) {
            $('contentCheckResult').innerHTML = `
                <div class="check-result" style="background:rgba(255,165,2,.08);color:var(--warning);border:1px solid rgba(255,165,2,.2);">
                    &#x1f6ab; 检测服务暂不可用，请确认服务器已启动
                </div>`;
        }
    }, 800);
}

// CSS 脉冲动画注入
(function injectStyles() {
    const s = document.createElement('style');
    s.textContent = '@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.4} }';
    document.head.appendChild(s);
})();

async function sendEmail() {
    const receiverId = $('composeReceiver').value;
    const subject = $('composeSubject').value.trim();
    const content = $('composeContent').value.trim();

    if (!receiverId) return toast('请选择收件人', 'error');
    if (!subject) return toast('请输入主题', 'error');
    if (!content) return toast('请输入邮件内容', 'error');

    // 敏感信息检测
    try {
        const sensitiveRes = await api('POST', '/emails/check-sensitive', { subject, content });
        if (sensitiveRes.success && sensitiveRes.found) {
            showSensitiveWarning(sensitiveRes);
            return;
        }
    } catch (_) {
        // 检测服务不可用时直接发送
    }

    doSendEmail(receiverId, subject, content);
}

async function doSendEmail(receiverId, subject, content) {
    try {
        const res = await api('POST', '/emails/send', {
            sender_id: STATE.currentUser.id,
            receiver_id: parseInt(receiverId),
            subject,
            content,
        });

        if (!res) throw new Error('无响应');

        if (res.success) {
            if (res.spam_check && res.spam_check.is_spam) {
                const llmInfo = buildLlmInfo(res.llm_analysis);
                toast('邮件已发送，但AI检测为垃圾邮件，已自动归入收件人垃圾箱', 'warning');
                $('contentCheckResult').innerHTML = `
                    <div class="check-result danger">
                        <strong>AI智能识别：</strong>该邮件被检测为垃圾邮件（评分: ${(res.spam_check.score * 100).toFixed(0)}%），已正常发出<br>
                        原因: ${(res.spam_check.reasons || []).join('; ')}
                        ${llmInfo}
                        <br><small>收件人将收到预警通知，该邮件自动归入垃圾箱</small>
                    </div>`;
            } else {
                toast('邮件发送成功！', 'success');
                $('contentCheckResult').innerHTML = '';
            }
            $('composeSubject').value = '';
            $('composeContent').value = '';
            loadBadges();
        } else {
            toast(res.message || '发送失败', 'error');
        }
    } catch (e) {
        toast('发送失败：服务器未响应，请确认已启动', 'error');
    }
}

// LLM 分析结果展示
function buildLlmInfo(llm) {
    if (!llm) return '';
    if (llm.error) return `
        <div class="llm-panel" style="border-color:rgba(255,165,2,.15);background:rgba(255,165,2,.04);">
            <div class="llm-header" style="color:var(--warning);">&#x26a0;&#xfe0f; DeepSeek 暂不可用</div>
            <div class="llm-field">已自动回退到本地模型检测</div>
        </div>`;
    if (llm.is_spam === null || llm.is_spam === undefined) return '';

    const riskLabel = { low: '低风险', medium: '中风险', high: '高风险', critical: '严重威胁' };
    const label = riskLabel[llm.risk_level] || llm.risk_level || '未知';
    const riskClass = ['low','medium','high','critical'].includes(llm.risk_level) ? llm.risk_level : 'medium';

    return `
        <div class="llm-panel">
            <div class="llm-header">
                &#x1f9e0; DeepSeek V4 语义分析
                <span class="llm-badge ${riskClass}">${label}</span>
            </div>
            ${llm.category ? `<div class="llm-field"><strong>分类:</strong> ${llm.category}</div>` : ''}
            ${llm.reasoning ? `<div class="llm-field"><strong>分析:</strong> ${llm.reasoning}</div>` : ''}
            ${llm.suggestions ? `<div class="llm-field"><strong>建议:</strong> ${llm.suggestions}</div>` : ''}
            <div class="llm-footer">
                <span style="width:6px;height:6px;background:var(--accent);border-radius:50%;box-shadow:0 0 6px var(--accent-glow);"></span>
                Powered by DeepSeek V4 Flash
            </div>
        </div>`;
}

// ==================== 深度检测 ====================

async function runDeepScan(text) {
    if (text.length < 15) return null;
    try {
        return await api('POST', '/detect/comprehensive', {
            subject: ($('composeSubject')?.value || ''),
            content: text,
            sender_email: '',
            sender_name: STATE.currentUser?.username || '',
            sender_id: STATE.currentUser?.id || null,
        });
    } catch (_) { return null; }
}

function buildDeepPanel(deep) {
    if (!deep) return '';
    const riskClass = deep.overall_risk === '高风险' ? 'danger' : deep.overall_risk === '中风险' ? 'warn' : 'safe';

    let sections = '';

    // 诈骗检测
    if (deep.fraud && !deep.fraud.error) {
        const f = deep.fraud;
        sections += `
            <div class="dp-section">
                <div class="dp-label">&#x1f575;&#xfe0f; 诈骗套路分析 ${f.is_fraud ? '<span class="fraud-tag">诈骗警告</span>' : ''}</div>
                <div class="dp-value ${f.is_fraud ? 'danger' : 'safe'}">
                    ${f.fraud_type || '正常邮件'}
                    ${f.risk_score ? ` (风险评分: ${(f.risk_score*100).toFixed(0)}%)` : ''}
                </div>
                ${f.reasoning ? `<div style="font-size:.78rem;color:var(--text-secondary);margin-top:4px;">${f.reasoning}</div>` : ''}
                ${f.tactics && f.tactics.length ? `<div style="margin-top:4px;">${f.tactics.map(t=>`<span class="tactic-tag">${t}</span>`).join('')}</div>` : ''}
                ${f.red_flags && f.red_flags.length ? f.red_flags.map(r => `<div class="red-flag">&#x1f6a9; ${r}</div>`).join('') : ''}
            </div>`;
    }

    // 身份检测
    if (deep.identity && !deep.identity.error) {
        const id = deep.identity;
        sections += `
            <div class="dp-section">
                <div class="dp-label">&#x1f464; 发件人身份校验</div>
                <div class="dp-value ${id.is_suspicious ? 'warn' : 'safe'}">
                    ${id.risk_level || '安全'}
                    ${id.reasons && id.reasons.length ? ' - ' + id.reasons.join(', ') : ''}
                </div>
            </div>`;
    }

    // 链接扫描
    if (deep.urls && !deep.urls.error) {
        const u = deep.urls;
        const urlCount = (u.urls || []).length;
        sections += `
            <div class="dp-section">
                <div class="dp-label">&#x1f517; 链接风险扫描 (${urlCount} 个)</div>
                <div class="dp-value ${u.risk_score >= 0.5 ? 'danger' : u.risk_score > 0 ? 'warn' : 'safe'}">
                    风险评分: ${(u.risk_score*100).toFixed(0)}%
                </div>
                ${(u.warnings || []).map(w => `<div class="red-flag">&#x26a0;&#xfe0f; ${w}</div>`).join('')}
                ${(u.urls || []).slice(0,3).map(ur => `
                    <div style="font-size:.75rem;color:var(--text-muted);margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                        ${ur.risk==='high'?'&#x1f534':'&#x1f7e1'} ${ur.url.substring(0,60)}
                        ${ur.reason ? ` <span style="color:var(--danger)">(${ur.reason})</span>` : ''}
                    </div>
                `).join('')}
            </div>`;
    }

    if (!sections) return '';

    return `
        <div class="deep-panel" style="margin-top:10px;">
            <div class="dp-header">
                &#x1f50d; 深度安全扫描
                <span class="risk-badge ${riskClass}">${deep.overall_risk}</span>
            </div>
            ${sections}
        </div>`;
}

// ==================== AI 增强助手 ====================

async function loadAiAssistant(emailId, senderName, subject, content) {
    const panel = $('aiAssistantPanel');
    if (!panel) return;
    panel.innerHTML = '<div class="ai-loading">&#x1f9e0; AI 正在分析邮件...</div>';

    try {
        const [replyRes, sentimentRes, todoRes] = await Promise.all([
            api('POST', '/ai/reply-suggestions', { subject, content: (content||'').substring(0, 1500), sender_name: senderName }),
            api('POST', '/ai/sentiment', { subject, content: (content||'').substring(0, 1000) }),
            api('POST', '/ai/extract-todos', { subject, content: (content||'').substring(0, 1500) }),
        ]);

        let html = '<div class="ai-panel">';

        // 情感分析
        if (sentimentRes.success) {
            const s = sentimentRes;
            const sentCls = s.sentiment === '正面' ? 'pos' : s.sentiment === '负面' ? 'neg' : 'neu';
            const urgCls = s.urgency === '紧急' ? 'urg' : s.urgency === '重要' ? 'imp' : 'neu';
            html += `
                <div class="ai-header">&#x1f9e0; AI 邮件分析</div>
                <div class="ai-sentiment-row">
                    <span class="ai-sentiment-tag ${sentCls}">${s.sentiment}</span>
                    <span class="ai-sentiment-tag ${urgCls}">${s.urgency}</span>
                    <span style="font-size:.78rem;color:var(--text-secondary);">${s.key_intent || ''}</span>
                    ${(s.emotion_tags||[]).map(t=>`<span style="font-size:.7rem;color:var(--text-muted);">#${t}</span>`).join('')}
                </div>`;
        }

        // 日程待办
        if (todoRes.success && todoRes.events && todoRes.events.length > 0) {
            html += `<div style="padding:8px 20px;font-size:.75rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:.05em;">&#x1f4c5; 日程/待办</div>`;
            todoRes.events.forEach(ev => {
                html += `
                    <div class="ai-todo-item">
                        <span class="todo-icon">${ev.type==='会议'?'&#x1f4c5;':ev.type==='截止日'?'&#x23f0;':'&#x2705;'}</span>
                        <span class="todo-info">${ev.title}</span>
                        ${ev.time ? `<span class="todo-time">${ev.time}</span>` : ''}
                    </div>`;
            });
        }

        // 回复建议
        if (replyRes.success && replyRes.replies && replyRes.replies.length > 0) {
            html += `<div style="padding:8px 20px;font-size:.75rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:.05em;">&#x1f4ac; 智能回复建议</div>`;
            replyRes.replies.forEach(r => {
                html += `
                    <div class="ai-reply-item" onclick="applyReply('${_escapeHtml(r.text)}')">
                        <div class="ai-reply-style">${r.style}</div>
                        <div class="ai-reply-text">${r.text}</div>
                        <div class="ai-reply-action">点击复制到剪贴板</div>
                    </div>`;
            });
        }

        html += '</div>';
        panel.innerHTML = html;
    } catch (e) {
        panel.innerHTML = '';
    }
}

// ==================== AI 写邮件辅助 ====================

async function aiGenerateTemplate() {
    const input = $('templatePurpose');
    if (input.style.display === 'none') {
        input.style.display = 'block';
        input.focus();
        return;
    }
    const purpose = input.value.trim();
    if (!purpose) return toast('请输入模板场景', 'error');

    input.style.display = 'none';
    $('aiTemplateResult').innerHTML = '<div class="ai-loading">&#x1f9e0; AI 正在生成模板...</div>';

    const res = await api('POST', '/ai/template', { purpose });
    if (res.success) {
        $('aiTemplateResult').innerHTML = `
            <div class="ai-template-result">
                <div class="tmpl-subject">${res.subject || ''}</div>
                <div class="tmpl-body">${res.body || ''}</div>
                ${(res.tips||[]).map(t=>`<div style="font-size:.72rem;color:var(--text-muted);margin-top:4px;">&#x1f4a1; ${t}</div>`).join('')}
                <div class="tmpl-apply" onclick="applyTemplate('${_escapeHtml(res.subject||'')}','${_escapeHtml(res.body||'')}')">&#x2714; 应用到编辑器</div>
            </div>`;
    } else {
        toast('生成失败: ' + (res.error||'未知'), 'error');
    }
}

async function aiPolishEmail(style) {
    const content = $('composeContent').value.trim();
    if (content.length < 10) return toast('请先输入邮件内容', 'error');

    $('aiTemplateResult').innerHTML = '<div class="ai-loading">&#x2728; AI 正在润色...</div>';

    const res = await api('POST', '/ai/polish', { content, style });
    if (res.success) {
        $('aiTemplateResult').innerHTML = `
            <div class="ai-template-result">
                <div class="tmpl-body">${res.polished || content}</div>
                ${(res.changes||[]).map(c=>`<div style="font-size:.72rem;color:var(--accent-light);margin-top:4px;">&#x2705; ${c}</div>`).join('')}
                <div class="tmpl-apply" onclick="$('composeContent').value='${_escapeHtml(res.polished||'')}';$('aiTemplateResult').innerHTML='';toast('已应用润色','success')">&#x2714; 应用润色</div>
            </div>`;
    } else {
        toast('润色失败', 'error');
    }
}

// ==================== AI 翻译 ====================

async function doTranslate(direction) {
    const bodyEl = $('detailBody');
    const text = (bodyEl ? bodyEl.textContent : '').trim();
    if (!text || text === '(无内容)') return toast('没有可翻译的内容', 'error');

    // 高亮当前按钮
    document.querySelectorAll('.translate-toggle').forEach(b => b.classList.remove('active'));
    const btnMap = { 'auto': 'btnTransAuto', 'en2zh': 'btnTransEn', 'zh2en': 'btnTransZh' };
    const btn = $(btnMap[direction]);
    if (btn) btn.classList.add('active');

    $('transPanel').innerHTML = '<div class="trans-loading">&#x1f310; AI 正在翻译...</div>';

    try {
        const res = await api('POST', '/ai/translate', { text, direction });
        if (!res.success) { toast(res.message, 'error'); return; }

        const origLines = text.split('\n').filter(l => l.trim());
        const transLines = res.translated.split('\n').filter(l => l.trim());
        const isEn = res.direction === 'en2zh';
        const srcLang = isEn ? 'EN' : 'ZH';
        const dstLang = isEn ? 'ZH' : 'EN';

        let html = `<div class="trans-panel">
            <div class="trans-header">
                &#x1f310; AI 翻译对照
                <span class="trans-lang">${srcLang} &#x2192; ${dstLang}</span>
            </div>
            <div class="trans-body">`;

        const maxLines = Math.min(origLines.length, transLines.length);
        for (let i = 0; i < maxLines; i++) {
            html += `
                <div class="trans-row">
                    <div class="trans-orig">${origLines[i]}</div>
                    <div class="trans-result">${transLines[i]}</div>
                </div>`;
        }

        // 如果原文行数多于译文，补齐
        for (let i = maxLines; i < origLines.length; i++) {
            html += `
                <div class="trans-row">
                    <div class="trans-orig">${origLines[i]}</div>
                    <div class="trans-result" style="color:var(--text-muted);">—</div>
                </div>`;
        }

        html += '</div></div>';
        $('transPanel').innerHTML = html;
    } catch (e) {
        $('transPanel').innerHTML = '<div class="trans-loading" style="color:var(--danger);">翻译失败，请重试</div>';
    }
}

function applyTemplate(subject, body) {
    $('composeSubject').value = subject;
    $('composeContent').value = body;
    $('aiTemplateResult').innerHTML = '';
    toast('模板已应用', 'success');
}

function applyReply(text) {
    navigator.clipboard.writeText(text).then(() => {
        toast('回复已复制，可粘贴到写邮件中使用', 'success');
    }).catch(() => {
        toast('复制失败，请手动选择文本', 'error');
    });
}

function _escapeHtml(str) {
    if (!str) return '';
    return str.replace(/'/g, "\\'").replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// ==================== 预警 ====================
async function loadWarnings() {
    if (!STATE.currentUser) return;
    const res = await api('GET', `/warnings/${STATE.currentUser.id}`);
    if (res.success) {
        const list = res.warnings;
        if (list.length === 0) {
            $('warningList').innerHTML = '<div class="empty"><div class="icon">🔔</div><p>暂无预警信息</p></div>';
        } else {
            $('warningList').innerHTML = list.map(w => `
                <div class="warning-item ${w.is_read ? '' : 'unread'}" onclick="markWarningRead(${w.id})">
                    <span class="warning-icon">${w.is_read ? '🔕' : '🔔'}</span>
                    <span class="warning-msg">${w.message}</span>
                    <span class="warning-time">${formatTime(w.created_at)}</span>
                    ${!w.is_read ? '<button class="btn btn-success btn-xs" onclick="event.stopPropagation();markWarningRead(' + w.id + ')">标记已读</button>' : ''}
                </div>
            `).join('');
        }
    }
}

async function markWarningRead(warningId) {
    await api('POST', `/warnings/${warningId}/read`);
    loadWarnings();
    loadBadges();
}

// ==================== 模拟接收外部邮件 ====================
async function receiveExternalEmail() {
    const senderName = $('extSenderName').value.trim() || 'external@mail.com';
    const receiverId = $('extReceiver').value;
    const subject = $('extSubject').value.trim();
    const content = $('extContent').value.trim();

    if (!receiverId) return toast('请选择收件人', 'error');
    if (!subject) return toast('请输入主题', 'error');

    const res = await api('POST', '/external/receive', {
        sender_name: senderName,
        receiver_id: parseInt(receiverId),
        subject,
        content,
    });

    if (res.success) {
        if (res.is_spam) {
            toast(`邮件已被拦截！垃圾评分: ${(res.spam_score * 100).toFixed(0)}%，已放入垃圾箱`, 'warning');
        } else {
            toast('邮件已成功接收！', 'success');
        }
        $('extSubject').value = '';
        $('extContent').value = '';
        loadBadges();
    } else {
        toast(res.message, 'error');
    }
}

// ==================== 系统设置 ====================

async function loadSettings() {
    // 检查 LLM 状态
    const res = await api('GET', '/llm/status');
    if (res.success && res.has_key) {
        $('apiKeyInput').placeholder = '已设置 (隐藏)';
    }
}

async function saveApiKey() {
    const key = $('apiKeyInput').value.trim();
    if (!key) return toast('请输入 API Key', 'error');
    if (!key.startsWith('sk-')) return toast('API Key 格式不正确，应以 sk- 开头', 'error');

    const res = await api('POST', '/llm/config', { api_key: key });
    const statusEl = $('apiStatus');
    statusEl.style.display = 'block';
    if (res.success) {
        statusEl.style.background = '#f0fdf4';
        statusEl.style.color = '#166534';
        statusEl.innerHTML = res.message;
        toast(res.message, 'success');
        $('apiKeyInput').value = '';
        $('apiKeyInput').placeholder = '已设置 (隐藏)';
    } else {
        statusEl.style.background = '#fef2f2';
        statusEl.style.color = '#991b1b';
        statusEl.innerHTML = res.message;
        toast(res.message, 'error');
    }
}

async function testApiConnection() {
    const statusEl = $('apiStatus');
    statusEl.style.display = 'block';
    statusEl.style.background = '#fefce8';
    statusEl.style.color = '#854d0e';
    statusEl.innerHTML = '正在测试连接...';

    const res = await api('POST', '/llm/test');
    if (res.success) {
        statusEl.style.background = '#f0fdf4';
        statusEl.style.color = '#166534';
        statusEl.innerHTML = res.message;
        toast('DeepSeek API 连接成功！', 'success');
    } else {
        statusEl.style.background = '#fef2f2';
        statusEl.style.color = '#991b1b';
        statusEl.innerHTML = res.message;
        toast(res.message, 'error');
    }
}

// ==================== 邮件分类标签映射 ====================

function mapCategoryClass(cat) {
    const m = {
        '工作通知': 'work', '个人邮件': 'personal', '订阅推广': 'subscription',
        '验证码': 'auth', '物流通知': 'logistics', '账单财务': 'finance',
        '社交互动': 'social', '系统通知': 'auth',
    };
    return m[cat] || 'other';
}

// ==================== 摘要预览 ====================
let _summaryTimer = null;

async function showSummary(emailId, el) {
    clearTimeout(_summaryTimer);
    _summaryTimer = setTimeout(async () => {
        try {
            const res = await api('GET', `/emails/${emailId}`);
            if (!res.success) return;
            const e = res.email;
            const fullText = `${e.subject}\n${e.content}`;
            if (fullText.length < 200) return;
            const sum = await api('POST', '/emails/summarize', { subject: e.subject, content: e.content });
            if (sum.success && sum.summary) {
                const div = document.createElement('div');
                div.className = 'summary-toast';
                div.id = '_summaryToast';
                div.innerHTML = `<div class="sum-label">AI 摘要</div>${sum.summary}`;
                document.body.appendChild(div);
            }
        } catch (_) { }
    }, 600);
}

function hideSummary() {
    clearTimeout(_summaryTimer);
    const t = document.getElementById('_summaryToast');
    if (t) t.remove();
}

// ==================== 敏感信息警告 ====================

function showSensitiveWarning(sensitiveRes) {
    const itemsHtml = sensitiveRes.items.map(i => `
        <div class="sensitive-item">
            <span class="si-type">&#x26a0;&#xfe0f; ${i.type}</span>
            <span class="si-sample">${(i.sample || []).join(', ')}</span>
            <span style="color:var(--text-muted);font-size:.75rem;margin-left:auto;">${i.count}处</span>
        </div>
    `).join('');

    const modal = $('modal');
    const content = $('modalContent');
    content.innerHTML = `
        <h3>&#x1f6ab; 敏感信息警告</h3>
        <p style="color:var(--text-secondary);font-size:.85rem;margin:8px 0 16px;">
            检测到邮件中包含敏感信息（风险等级: <strong style="color:var(--danger);">${sensitiveRes.risk_level}</strong>），确认发送可能导致信息泄露。
        </p>
        <div class="sensitive-list">${itemsHtml}</div>
        <div style="display:flex;gap:10px;margin-top:20px;">
            <button class="btn btn-outline btn-sm" onclick="closeModal()" style="flex:1;">取消发送</button>
            <button class="btn btn-danger btn-sm" onclick="forceSendSensitive()" style="flex:1;">确认发送</button>
        </div>
    `;
    modal.classList.add('active');
}

function closeModal() {
    $('modal').classList.remove('active');
    // 保存待发送参数用于强制发送
    delete window._pendingSend;
}

function forceSendSensitive() {
    closeModal();
    const receiverId = $('composeReceiver').value;
    const subject = $('composeSubject').value.trim();
    const content = $('composeContent').value.trim();
    doSendEmail(receiverId, subject, content);
}

// ==================== 智能清理助手 ====================

function loadCleanupPage() {
    $('cleanupStats').style.display = 'none';
    $('cleanupResults').innerHTML = '';
    $('cleanupActions').style.display = 'none';
}

async function startCleanupScan() {
    $('btnCleanupScan').disabled = true;
    $('btnCleanupScan').innerHTML = '<span class="status-dot" style="background:var(--accent);box-shadow:0 0 8px var(--accent-glow);animation:pulse 1.2s ease infinite;display:inline-block;"></span> 正在扫描...';
    $('cleanupResults').innerHTML = '<div class="empty"><div class="icon">&#x1f50d;</div><p>AI 正在分析全邮箱，请稍候...</p></div>';

    try {
        const res = await api('GET', `/emails/cleanup-scan/${STATE.currentUser.id}`);
        if (res.success) {
            $('cleanupStats').style.display = 'flex';
            $('cleanupStats').innerHTML = `
                <div class="cleanup-stat">
                    <div class="val">${res.total_suggested}</div>
                    <div class="lbl">建议清理</div>
                </div>
                <div class="cleanup-stat">
                    <div class="val">${res.categories.length}</div>
                    <div class="lbl">分类类别</div>
                </div>
            `;
            renderCleanupResults(res.categories);
            $('cleanupActions').style.display = 'flex';
        }
    } catch (e) {
        $('cleanupResults').innerHTML = '<div class="empty"><div class="icon">&#x26a0;&#xfe0f;</div><p>扫描失败，请确认服务器已启动</p></div>';
    }

    $('btnCleanupScan').disabled = false;
    $('btnCleanupScan').innerHTML = '&#x1f50d; 重新扫描';
}

function renderCleanupResults(categories) {
    let html = '';
    categories.forEach((cat, idx) => {
        html += `
            <div class="cleanup-category">
                <div class="cat-header">
                    <h3>&#x1f4e6; ${cat.name} <span class="count">(${cat.count}封)</span></h3>
                    <span class="select-all" onclick="toggleCatAll(${idx})">全选/取消</span>
                </div>
                <p style="font-size:.78rem;color:var(--text-muted);margin-bottom:12px;">${cat.reason}</p>
                ${cat.emails.map(e => `
                    <div class="cat-email" onclick="toggleCheck(this)">
                        <input type="checkbox" data-eid="${e.id}" data-cat="${idx}">
                        <span class="ce-subject">${e.subject || '(无主题)'}</span>
                        <span class="ce-time">${formatTime(e.created_at)}</span>
                    </div>
                `).join('')}
            </div>`;
    });
    window._cleanupData = categories;
    $('cleanupResults').innerHTML = html;
}

function toggleCheck(el) {
    const cb = el.querySelector('input[type="checkbox"]');
    if (cb) cb.checked = !cb.checked;
}

function toggleCatAll(idx) {
    const cbs = document.querySelectorAll(`input[data-cat="${idx}"]`);
    const allChecked = Array.from(cbs).every(c => c.checked);
    cbs.forEach(c => { c.checked = !allChecked; });
}

async function batchCleanup(action) {
    const cbs = document.querySelectorAll('#cleanupResults input[type="checkbox"]:checked');
    const ids = Array.from(cbs).map(c => parseInt(c.dataset.eid));
    if (ids.length === 0) return toast('请先选择要清理的邮件', 'error');

    const label = action === 'delete' ? '删除' : '移入垃圾箱';
    if (!confirm(`确定要${label} ${ids.length} 封邮件吗？此操作不可恢复。`)) return;

    const res = await api('POST', '/emails/batch-action', { email_ids: ids, action });
    if (res.success) {
        toast(res.message, 'success');
        startCleanupScan();
        loadBadges();
    } else {
        toast(res.message, 'error');
    }
}

// ==================== 初始化 ====================
document.addEventListener('DOMContentLoaded', () => {
    // 防止未登录访问
    if (!STATE.currentUser) {
        $('authPage').style.display = 'flex';
        $('appPage').classList.remove('active');
    }
});
