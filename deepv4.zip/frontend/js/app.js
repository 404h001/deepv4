// 全局状态
const STATE = {
    currentUser: null,
    faceStream: null,
    faceStreamReg: null,
    capturedFace: null,
    capturedFaceReg: null,
};

const API = '/api';

// ==================== 工具函数 ====================
function $(id) { return document.getElementById(id); }
function toast(msg, type = 'info') {
    const t = document.createElement('div');
    t.className = `toast ${type}`;
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 3000);
}

async function api(method, url, body = null) {
    const opts = { method, headers: { 'Content-Type': 'application/json' } };
    if (body) opts.body = JSON.stringify(body);
    const resp = await fetch(API + url, opts);
    return resp.json();
}

function formatTime(ts) {
    if (!ts) return '';
    const d = new Date(ts);
    const now = new Date();
    const diff = now - d;
    if (diff < 60000) return '刚刚';
    if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前';
    if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前';
    return d.toLocaleDateString('zh-CN') + ' ' + d.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
}

// ==================== 导航 ====================
function showPage(name) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.sidebar-nav a').forEach(a => a.classList.remove('active'));

    const page = $('page-' + name);
    if (page) page.classList.add('active');
    const link = document.querySelector(`[data-page="${name}"]`);
    if (link) link.classList.add('active');

    if (name === 'dashboard') loadDashboard();
    if (name === 'inbox') loadInbox();
    if (name === 'sent') loadSent();
    if (name === 'spam') loadSpam();
    if (name === 'compose') loadComposeForm();
    if (name === 'warnings') loadWarnings();
    if (name === 'settings') loadSettings();
}

function showEmailDetail(emailId) {
    showPage('detail');
    loadEmailDetail(emailId);
}

// ==================== Auth ====================
function showRegister() {
    $('loginForm').style.display = 'none';
    $('registerForm').style.display = 'block';
}
function showLogin() {
    $('registerForm').style.display = 'none';
    $('loginForm').style.display = 'block';
}

async function handleRegister() {
    const username = $('regUsername').value.trim();
    const password = $('regPassword').value.trim();
    const password2 = $('regPassword2').value.trim();

    if (!username || !password) return toast('请填写用户名和密码', 'error');
    if (username.length < 3) return toast('用户名至少3个字符', 'error');
    if (password.length < 6) return toast('密码至少6个字符', 'error');
    if (password !== password2) return toast('两次密码不一致', 'error');

    const res = await api('POST', '/register', { username, password });
    if (res.success) {
        toast('注册成功！', 'success');
        // 如果已拍摄人脸，注册人脸
        if (STATE.capturedFaceReg && res.user_id) {
            const faceRes = await api('POST', '/face/register', {
                user_id: res.user_id,
                face_image: STATE.capturedFaceReg
            });
            if (faceRes.success) toast('人脸注册成功！', 'success');
            else toast(faceRes.message, 'error');
        }
        showLogin();
        $('regUsername').value = '';
        $('regPassword').value = '';
        $('regPassword2').value = '';
    } else {
        toast(res.message, 'error');
    }
}

async function handleLogin() {
    const username = $('loginUsername').value.trim();
    const password = $('loginPassword').value.trim();
    if (!username || !password) return toast('请输入用户名和密码', 'error');

    const res = await api('POST', '/login', { username, password });
    if (res.success) {
        STATE.currentUser = res.user;
        enterApp();
    } else {
        toast(res.message, 'error');
    }
}

// ==================== 人脸摄像头 ====================
async function startFaceCamera() {
    try {
        STATE.faceStream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 } });
        const video = $('faceVideo');
        video.srcObject = STATE.faceStream;
        video.style.display = 'block';
        $('btnFaceStart').style.display = 'none';
        $('btnFaceLogin').style.display = 'block';
        $('facePreview').style.display = 'none';
    } catch (e) {
        toast('无法访问摄像头: ' + e.message, 'error');
    }
}

async function handleFaceLogin() {
    const username = $('loginUsername').value.trim();
    if (!username) return toast('请先输入用户名', 'error');

    const video = $('faceVideo');
    const canvas = $('faceCanvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0);

    const imageData = canvas.toDataURL('image/jpeg');
    $('facePreview').src = imageData;
    $('facePreview').style.display = 'block';

    const res = await api('POST', '/login/face', { username, face_image: imageData });
    if (res.success) {
        STATE.currentUser = res.user;
        stopCamera(STATE.faceStream);
        enterApp();
    } else {
        toast(res.message, 'error');
    }
}

async function startFaceCameraReg() {
    try {
        STATE.faceStreamReg = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 } });
        const video = $('faceVideoReg');
        video.srcObject = STATE.faceStreamReg;
        video.style.display = 'block';
        $('btnFaceStartReg').style.display = 'none';
        $('btnFaceCaptureReg').style.display = 'block';
    } catch (e) {
        toast('无法访问摄像头: ' + e.message, 'error');
    }
}

function captureFaceReg() {
    const video = $('faceVideoReg');
    const canvas = $('faceCanvasReg');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0);
    STATE.capturedFaceReg = canvas.toDataURL('image/jpeg');
    $('facePreviewReg').src = STATE.capturedFaceReg;
    $('facePreviewReg').style.display = 'block';
    toast('人脸已捕捉', 'success');
    stopCamera(STATE.faceStreamReg);
}

function stopCamera(stream) {
    if (stream) {
        stream.getTracks().forEach(t => t.stop());
    }
}

// ==================== 进入应用 ====================
function enterApp() {
    $('authPage').style.display = 'none';
    $('appPage').classList.add('active');
    $('sidebarUsername').textContent = STATE.currentUser.username;
    loadDashboard();
    loadBadges();
}

function handleLogout() {
    STATE.currentUser = null;
    $('appPage').classList.remove('active');
    $('authPage').style.display = 'flex';
    showLogin();
    $('loginUsername').value = '';
    $('loginPassword').value = '';
}

// ==================== 统计数据 ====================
async function loadBadges() {
    const stats = await api('GET', `/stats/${STATE.currentUser.id}`);
    if (stats.success) {
        $('spamBadge').textContent = stats.stats.spam_count || '0';
        $('warnBadge').textContent = stats.stats.unread_warnings || '0';
    }
}

// ==================== 仪表盘 ====================
async function loadDashboard() {
    if (!STATE.currentUser) return;
    const stats = await api('GET', `/stats/${STATE.currentUser.id}`);
    if (stats.success) {
        const s = stats.stats;
        $('dashboardStats').innerHTML = `
            <div class="stat-card primary">
                <div class="stat-icon">&#x1f4e8;</div>
                <div class="stat-value">${s.normal_count}</div>
                <div class="stat-label">Normal Emails · 正常邮件</div>
            </div>
            <div class="stat-card danger">
                <div class="stat-icon">&#x1f6ab;</div>
                <div class="stat-value">${s.spam_count}</div>
                <div class="stat-label">Blocked Spam · 已拦截</div>
            </div>
            <div class="stat-card warning">
                <div class="stat-icon">&#x26a0;&#xfe0f;</div>
                <div class="stat-value">${s.unread_warnings}</div>
                <div class="stat-label">Alerts · 未读预警</div>
            </div>
            <div class="stat-card success">
                <div class="stat-icon">&#x1f9e0;</div>
                <div class="stat-value">AI</div>
                <div class="stat-label">DeepSeek V4 · 在线防护</div>
            </div>
        `;
        $('spamBadge').textContent = s.spam_count || '0';
        $('warnBadge').textContent = s.unread_warnings || '0';
    }

    const inbox = await api('GET', `/emails/inbox/${STATE.currentUser.id}`);
    if (inbox.success) {
        const list = inbox.emails.slice(0, 5);
        if (list.length === 0) {
            $('recentEmails').innerHTML = '<div class="empty"><div class="icon">📭</div><p>暂无邮件</p></div>';
        } else {
            $('recentEmails').innerHTML = list.map(e => renderEmailItem(e, 'inbox')).join('');
        }
    }
}

// ==================== 收件箱 ====================
async function loadInbox() {
    if (!STATE.currentUser) return;
    const res = await api('GET', `/emails/inbox/${STATE.currentUser.id}`);
    if (res.success) {
        const list = res.emails;
        if (list.length === 0) {
            $('inboxList').innerHTML = '<div class="empty"><div class="icon">📭</div><p>收件箱为空</p></div>';
        } else {
            $('inboxList').innerHTML = list.map(e => renderEmailItem(e, 'inbox')).join('');
        }
    }
}

async function loadSent() {
    if (!STATE.currentUser) return;
    const res = await api('GET', `/emails/sent/${STATE.currentUser.id}`);
    if (res.success) {
        const list = res.emails;
        if (list.length === 0) {
            $('sentList').innerHTML = '<div class="empty"><div class="icon">📤</div><p>暂无已发送邮件</p></div>';
        } else {
            $('sentList').innerHTML = list.map(e => renderEmailItem(e, 'sent')).join('');
        }
    }
}

async function loadSpam() {
    if (!STATE.currentUser) return;
    const res = await api('GET', `/emails/spam/${STATE.currentUser.id}`);
    if (res.success) {
        const list = res.emails;
        if (list.length === 0) {
            $('spamList').innerHTML = '<div class="empty"><div class="icon">🛡️</div><p>垃圾箱为空，系统正在保护您的邮箱</p></div>';
        } else {
            $('spamList').innerHTML = list.map(e => renderEmailItem(e, 'spam')).join('');
        }
    }
}

function renderEmailItem(e, type) {
    const spamBadge = e.is_spam ? '<span class="badge-spam">垃圾</span>' : '';
    const scoreHtml = e.spam_score > 0 ? `<span class="score">评分:${(e.spam_score * 100).toFixed(0)}%</span>` : '';

    let actions = '';
    if (type === 'inbox') {
        actions = `<button class="btn btn-warning btn-xs" onclick="event.stopPropagation();markSpam(${e.id})">标记垃圾</button>`;
    }
    if (type === 'spam') {
        actions = `<button class="btn btn-success btn-xs" onclick="event.stopPropagation();restoreEmail(${e.id})">恢复</button>`;
    }
    actions += `<button class="btn btn-danger btn-xs" onclick="event.stopPropagation();deleteEmailConfirm(${e.id})">删除</button>`;

    const senderDisplay = type === 'sent' ? `发给: ${e.receiver_name || ''}` : (e.sender_name || '');
    const preview = (e.content || '').substring(0, 50);

    return `
        <div class="email-item" onclick="showEmailDetail(${e.id})">
            <span class="sender">${senderDisplay}</span>
            <span class="subject">${spamBadge} ${e.subject}</span>
            <span class="preview">${preview}</span>
            ${scoreHtml}
            <span class="time">${formatTime(e.created_at)}</span>
            <span class="actions">${actions}</span>
        </div>
    `;
}

async function loadEmailDetail(emailId) {
    const res = await api('GET', `/emails/${emailId}`);
    if (res.success) {
        const e = res.email;
        const spamLabel = e.is_spam ? '<span class="badge-spam">垃圾邮件</span>' : '';
        $('emailDetail').innerHTML = `
            <div class="detail-header">
                <h2>${spamLabel} ${e.subject}</h2>
                <div class="detail-meta">
                    <span>发件人: ${e.sender_name}</span>
                    <span>收件人: ${e.receiver_name}</span>
                    <span>时间: ${formatTime(e.created_at)}</span>
                    ${e.spam_score > 0 ? `<span>垃圾评分: ${(e.spam_score * 100).toFixed(0)}%</span>` : ''}
                </div>
            </div>
            <div class="detail-body">${e.content || '(无内容)'}</div>
            <div class="detail-actions">
                ${e.is_spam
                    ? `<button class="btn btn-success btn-sm" onclick="restoreEmail(${e.id})">恢复为正常邮件</button>`
                    : `<button class="btn btn-warning btn-sm" onclick="markSpam(${e.id})">标记为垃圾邮件</button>`
                }
                <button class="btn btn-danger btn-sm" onclick="deleteEmailConfirm(${e.id})">删除</button>
                <button class="btn btn-outline btn-sm" onclick="showPage('inbox')">返回收件箱</button>
            </div>
        `;
    }
}

// ==================== 邮件操作 ====================
async function markSpam(emailId) {
    const res = await api('POST', `/emails/${emailId}/mark-spam`);
    if (res.success) {
        toast('已标记为垃圾邮件', 'success');
        loadInbox();
        loadBadges();
    }
}

async function restoreEmail(emailId) {
    const res = await api('POST', `/emails/${emailId}/restore`);
    if (res.success) {
        toast('已恢复为正常邮件', 'success');
        loadSpam();
        loadBadges();
    }
}

async function deleteEmailConfirm(emailId) {
    if (confirm('确定要删除这封邮件吗？')) {
        const res = await api('POST', `/emails/${emailId}/delete`);
        if (res.success) {
            toast('邮件已删除', 'success');
            loadInbox();
            loadSpam();
            loadBadges();
            showPage('inbox');
        }
    }
}

// ==================== 写邮件 ====================
async function loadComposeForm() {
    const res = await api('GET', '/users');
    if (res.success) {
        const users = res.users.filter(u => u.id !== STATE.currentUser.id);
        $('composeReceiver').innerHTML = '<option value="">选择收件人...</option>' +
            users.map(u => `<option value="${u.id}">${u.username}</option>`).join('');
    }
    $('composeSubject').value = '';
    $('composeContent').value = '';
    $('contentCheckResult').innerHTML = '';

    // 同时加载模拟接收页面的收件人
    const extReceiver = $('extReceiver');
    if (extReceiver) {
        const res2 = await api('GET', '/users');
        if (res2.success) {
            extReceiver.innerHTML = '<option value="">选择收件人...</option>' +
                res2.users.map(u => `<option value="${u.id}">${u.username}</option>`).join('');
        }
    }
}

async function checkContentRealtime() {
    const text = $('composeContent').value.trim();
    if (text.length < 10) {
        $('contentCheckResult').innerHTML = '';
        return;
    }
    const res = await api('POST', '/check-content', { text });
    if (res.success) {
        const llmInfo = buildLlmInfo(res.llm_analysis);
        if (res.is_spam) {
            $('contentCheckResult').innerHTML = `
                <div class="check-result danger">
                    <strong>警告：</strong>内容疑似垃圾邮件（评分: ${(res.score * 100).toFixed(0)}%）<br>
                    原因: ${res.reasons.join('; ')}
                    ${llmInfo}
                </div>`;
        } else {
            $('contentCheckResult').innerHTML = `
                <div class="check-result success">
                    <strong>内容检测通过</strong>，非垃圾内容
                    ${llmInfo}
                </div>`;
        }
    }
}

async function sendEmail() {
    const receiverId = $('composeReceiver').value;
    const subject = $('composeSubject').value.trim();
    const content = $('composeContent').value.trim();

    if (!receiverId) return toast('请选择收件人', 'error');
    if (!subject) return toast('请输入主题', 'error');
    if (!content) return toast('请输入邮件内容', 'error');

    const res = await api('POST', '/emails/send', {
        sender_id: STATE.currentUser.id,
        receiver_id: parseInt(receiverId),
        subject,
        content,
    });

    if (res.success) {
        if (res.spam_check && res.spam_check.is_spam) {
            const llmInfo = buildLlmInfo(res.llm_analysis);
            toast('邮件已发送，但AI检测为垃圾邮件，已自动归入收件人垃圾箱', 'warning');
            $('contentCheckResult').innerHTML = `
                <div class="check-result danger">
                    <strong>AI智能识别：</strong>该邮件被检测为垃圾邮件（评分: ${(res.spam_check.score * 100).toFixed(0)}%），已正常发出<br>
                    原因: ${(res.spam_check.reasons || []).join('; ')}
                    ${llmInfo}
                    <br><small>收件人将收到预警通知，该邮件自动归入垃圾箱</small>
                </div>`;
        } else {
            toast('邮件发送成功！', 'success');
            $('contentCheckResult').innerHTML = '';
        }
        $('composeSubject').value = '';
        $('composeContent').value = '';
        loadBadges();
    } else {
        toast(res.message, 'error');
    }
}

// LLM 分析结果展示
function buildLlmInfo(llm) {
    if (!llm || llm.error) return '';
    const riskLabel = { low: '低风险', medium: '中风险', high: '高风险', critical: '严重威胁' };
    const label = riskLabel[llm.risk_level] || llm.risk_level;
    return `
        <div class="llm-panel">
            <div class="llm-header">
                &#x1f9e0; DeepSeek V4 语义分析
                <span class="llm-badge ${llm.risk_level}">${label}</span>
            </div>
            ${llm.category ? `<div class="llm-field"><strong>分类:</strong> ${llm.category}</div>` : ''}
            ${llm.reasoning ? `<div class="llm-field"><strong>分析:</strong> ${llm.reasoning}</div>` : ''}
            ${llm.suggestions ? `<div class="llm-field"><strong>建议:</strong> ${llm.suggestions}</div>` : ''}
            <div class="llm-footer">
                <span style="width:6px;height:6px;background:var(--accent);border-radius:50%;box-shadow:0 0 6px var(--accent-glow);"></span>
                Powered by DeepSeek V4 Flash
            </div>
        </div>`;
}

// ==================== 预警 ====================
async function loadWarnings() {
    if (!STATE.currentUser) return;
    const res = await api('GET', `/warnings/${STATE.currentUser.id}`);
    if (res.success) {
        const list = res.warnings;
        if (list.length === 0) {
            $('warningList').innerHTML = '<div class="empty"><div class="icon">🔔</div><p>暂无预警信息</p></div>';
        } else {
            $('warningList').innerHTML = list.map(w => `
                <div class="warning-item ${w.is_read ? '' : 'unread'}" onclick="markWarningRead(${w.id})">
                    <span class="warning-icon">${w.is_read ? '🔕' : '🔔'}</span>
                    <span class="warning-msg">${w.message}</span>
                    <span class="warning-time">${formatTime(w.created_at)}</span>
                    ${!w.is_read ? '<button class="btn btn-success btn-xs" onclick="event.stopPropagation();markWarningRead(' + w.id + ')">标记已读</button>' : ''}
                </div>
            `).join('');
        }
    }
}

async function markWarningRead(warningId) {
    await api('POST', `/warnings/${warningId}/read`);
    loadWarnings();
    loadBadges();
}

// ==================== 模拟接收外部邮件 ====================
async function receiveExternalEmail() {
    const senderName = $('extSenderName').value.trim() || 'external@mail.com';
    const receiverId = $('extReceiver').value;
    const subject = $('extSubject').value.trim();
    const content = $('extContent').value.trim();

    if (!receiverId) return toast('请选择收件人', 'error');
    if (!subject) return toast('请输入主题', 'error');

    const res = await api('POST', '/external/receive', {
        sender_name: senderName,
        receiver_id: parseInt(receiverId),
        subject,
        content,
    });

    if (res.success) {
        if (res.is_spam) {
            toast(`邮件已被拦截！垃圾评分: ${(res.spam_score * 100).toFixed(0)}%，已放入垃圾箱`, 'warning');
        } else {
            toast('邮件已成功接收！', 'success');
        }
        $('extSubject').value = '';
        $('extContent').value = '';
        loadBadges();
    } else {
        toast(res.message, 'error');
    }
}

// ==================== 系统设置 ====================

async function loadSettings() {
    // 检查 LLM 状态
    const res = await api('GET', '/llm/status');
    if (res.success && res.has_key) {
        $('apiKeyInput').placeholder = '已设置 (隐藏)';
    }
}

async function saveApiKey() {
    const key = $('apiKeyInput').value.trim();
    if (!key) return toast('请输入 API Key', 'error');
    if (!key.startsWith('sk-')) return toast('API Key 格式不正确，应以 sk- 开头', 'error');

    const res = await api('POST', '/llm/config', { api_key: key });
    const statusEl = $('apiStatus');
    statusEl.style.display = 'block';
    if (res.success) {
        statusEl.style.background = '#f0fdf4';
        statusEl.style.color = '#166534';
        statusEl.innerHTML = res.message;
        toast(res.message, 'success');
        $('apiKeyInput').value = '';
        $('apiKeyInput').placeholder = '已设置 (隐藏)';
    } else {
        statusEl.style.background = '#fef2f2';
        statusEl.style.color = '#991b1b';
        statusEl.innerHTML = res.message;
        toast(res.message, 'error');
    }
}

async function testApiConnection() {
    const statusEl = $('apiStatus');
    statusEl.style.display = 'block';
    statusEl.style.background = '#fefce8';
    statusEl.style.color = '#854d0e';
    statusEl.innerHTML = '正在测试连接...';

    const res = await api('POST', '/llm/test');
    if (res.success) {
        statusEl.style.background = '#f0fdf4';
        statusEl.style.color = '#166534';
        statusEl.innerHTML = res.message;
        toast('DeepSeek API 连接成功！', 'success');
    } else {
        statusEl.style.background = '#fef2f2';
        statusEl.style.color = '#991b1b';
        statusEl.innerHTML = res.message;
        toast(res.message, 'error');
    }
}

// ==================== 初始化 ====================
document.addEventListener('DOMContentLoaded', () => {
    // 防止未登录访问
    if (!STATE.currentUser) {
        $('authPage').style.display = 'flex';
        $('appPage').classList.remove('active');
    }
});
